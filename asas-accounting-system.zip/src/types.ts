export type Client = {
  id: string;
  name: string;
  phone: string;
  email: string;
  idNumber: string;
  notes: string;
};

export type Developer = {
  id: string;
  name: string;
  contactPerson: string;
  phone: string;
  commissionNotes: string;
};

export type Agent = {
  id: string;
  name: string;
  fixedSalary: number;
};

export type Project = {
  id: string;
  name: string;
  developerId: string;
};

export type Sale = {
  id: string;
  date: string;
  clientId: string;
  developerId: string;
  projectId: string;
  apartmentReference: string;
  agentId: string;
  totalPrice: number;
  firstPayment: number;
  secondPayment: number;
  totalCommissionAgreed: number;
  agentCommissionAgreed: number;
  commissionReceivedSoFar: number;
  marketingCampaignId?: string;
};

export type CommissionPayment = {
  id: string;
  saleId: string;
  date: string;
  amount: number;
  type: 'received_from_developer' | 'paid_to_agent';
};

export type RevenueCategory = 'Commission Received' | 'Other Income' | 'Marketing Reimbursements' | 'Miscellaneous Income';

export type Revenue = {
  id: string;
  date: string;
  category: RevenueCategory;
  amount: number;
  description: string;
  saleId?: string;
};

export type ExpenseCategory = 'Founder Expenses' | 'Executive Director Expenses' | 'Sales Agent Salaries' | 'Sales Agent Commission Paid' | 'Transportation' | 'Advertising - Facebook' | 'Advertising - Google' | 'Advertising - TikTok' | 'Photographer' | 'Devices & Equipment' | 'Office Expenses' | 'Miscellaneous';

export type Expense = {
  id: string;
  date: string;
  category: ExpenseCategory;
  description: string;
  amount: number;
  projectId?: string;
  status: 'Paid' | 'Pending';
};

export type MarketingCampaign = {
  id: string;
  name: string;
  platform: 'Facebook' | 'Google' | 'TikTok' | 'Other';
  budget: number;
  leadsGenerated: number;
  appointmentsSet: number;
};


export type AppState = {
  sales: Sale[];
  expenses: Expense[];
};
