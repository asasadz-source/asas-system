import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '../lib/supabase';
import { Database } from '../types/supabase';

type Tables = Database['public']['Tables'];

export function useUsers(role?: 'admin' | 'agent' | 'client') {
  return useQuery({
    queryKey: ['users', role],
    queryFn: async () => {
      let query = supabase.from('users').select('*');
      if (role) {
        query = query.eq('role', role);
      }
      const { data, error } = await query.order('name');
      if (error) throw error;
      return data;
    },
  });
}

export function useProperties() {
  return useQuery({
    queryKey: ['properties'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('properties')
        .select('*, creator:users(name), features:property_features(*)')
        .order('created_at', { ascending: false });
      if (error) throw error;
      return data;
    },
  });
}

export function useDeals() {
  return useQuery({
    queryKey: ['deals'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('deals')
        .select('*, property:properties(*), buyer:users!deals_buyer_id_fkey(name), agent:users!deals_agent_id_fkey(name)')
        .order('created_at', { ascending: false });
      if (error) throw error;
      return data;
    },
  });
}

export function useExpenses() {
  return useQuery({
    queryKey: ['expenses'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('expenses')
        .select('*, creator:users(name)')
        .order('created_at', { ascending: false });
      if (error) throw error;
      return data;
    },
  });
}

export function usePayments() {
  return useQuery({
    queryKey: ['payments'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('payments')
        .select('*, deal:deals(*, property:properties(location))')
        .order('created_at', { ascending: false });
      if (error) throw error;
      return data;
    },
  });
}

export function useCommissions() {
  return useQuery({
    queryKey: ['commissions'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('commissions')
        .select('*, deal:deals(*, property:properties(location)), agent:users(name)')
        .order('created_at', { ascending: false });
      if (error) throw error;
      return data;
    },
  });
}

export function useCampaigns() {
  return useQuery({
    queryKey: ['campaigns'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('marketing_campaigns')
        .select('*')
        .order('created_at', { ascending: false });
      if (error) throw error;
      return data;
    },
  });
}

// Legacy hooks for compatibility during migration (optional, but good to have)
export function useClients() {
  return useUsers('client');
}

export function useAgents() {
  return useUsers('agent');
}

export function useProjects() {
  return useProperties();
}

export function useTransactions() {
  // This is tricky because transactions were a single table.
  // We'll return an empty array or try to combine payments and expenses.
  return useQuery({
    queryKey: ['transactions'],
    queryFn: async () => {
      const { data: payments } = await supabase.from('payments').select('*');
      const { data: expenses } = await supabase.from('expenses').select('*');
      
      const combined = [
        ...(payments || []).map(p => ({ ...p, type: 'PAYMENT' })),
        ...(expenses || []).map(e => ({ ...e, type: 'EXPENSE' }))
      ];
      
      return combined.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
    }
  });
}

export function usePartnersEquity() {
  // Placeholder for now as the RPC is gone
  return useQuery({
    queryKey: ['partners_equity'],
    queryFn: async () => {
      return {
        total_revenue: 0,
        total_expenses: 0,
        total_agent_payouts: 0,
        net_profit: 0,
        hammou_balance: 0,
        redouane_balance: 0
      };
    },
  });
}
