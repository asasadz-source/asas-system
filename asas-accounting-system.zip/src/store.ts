import React, { useState, useEffect } from 'react';
import { Client, Developer, Agent, Project, Sale, CommissionPayment, Revenue, Expense, MarketingCampaign } from './types';

function useLocalStorage<T>(key: string, initialValue: T): [T, React.Dispatch<React.SetStateAction<T>>] {
  const [storedValue, setStoredValue] = useState<T>(() => {
    try {
      const item = window.localStorage.getItem(key);
      return item ? JSON.parse(item) : initialValue;
    } catch (error) {
      console.error(error);
      return initialValue;
    }
  });

  useEffect(() => {
    try {
      window.localStorage.setItem(key, JSON.stringify(storedValue));
    } catch (error) {
      console.error(error);
    }
  }, [key, storedValue]);

  return [storedValue, setStoredValue];
}

export function useStore() {
  const [clients, setClients] = useLocalStorage<Client[]>('asas_clients', []);
  const [developers, setDevelopers] = useLocalStorage<Developer[]>('asas_developers', []);
  const [agents, setAgents] = useLocalStorage<Agent[]>('asas_agents', []);
  const [projects, setProjects] = useLocalStorage<Project[]>('asas_projects', []);
  const [sales, setSales] = useLocalStorage<Sale[]>('asas_sales', []);
  const [commissionPayments, setCommissionPayments] = useLocalStorage<CommissionPayment[]>('asas_commission_payments', []);
  const [revenues, setRevenues] = useLocalStorage<Revenue[]>('asas_revenues', []);
  const [expenses, setExpenses] = useLocalStorage<Expense[]>('asas_expenses', []);
  const [campaigns, setCampaigns] = useLocalStorage<MarketingCampaign[]>('asas_campaigns', []);

  return {
    clients, setClients,
    developers, setDevelopers,
    agents, setAgents,
    projects, setProjects,
    sales, setSales,
    commissionPayments, setCommissionPayments,
    revenues, setRevenues,
    expenses, setExpenses,
    campaigns, setCampaigns,
  };
}
