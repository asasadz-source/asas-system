import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { LayoutDashboard, Receipt, Wallet, FileText, Menu, X, Users, BarChart3, Building2, PieChart, LogOut, Briefcase, Megaphone, UserCircle } from 'lucide-react';

import { useAuth } from './context/AuthContext';
import { Dashboard } from './components/Dashboard';
import { Entities } from './components/Entities';
import { Expenses } from './components/Expenses';
import { Reports } from './components/Reports';
import { Sales } from './components/Sales';
import { Marketing } from './components/Marketing';
import { Toaster } from 'react-hot-toast';
import { Login } from './components/Login';
import { SetupRequired } from './components/SetupRequired';

export default function App() {
  const { user, profile, loading, isConfigured, signOut } = useAuth();
  const [activeTab, setActiveTab] = useState('dashboard');
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  useEffect(() => {
    if (isSidebarOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isSidebarOpen]);

  if (!isConfigured) {
    return <SetupRequired />;
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-neutral-50 flex items-center justify-center">
        <div className="w-12 h-12 border-4 border-slate-200 border-t-brand-gold-500 rounded-full animate-spin"></div>
      </div>
    );
  }

  if (!user) {
    return <Login />;
  }

  const toggleSidebar = () => setIsSidebarOpen(!isSidebarOpen);

  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'sales', label: 'Sales & Deals', icon: Briefcase },
    { id: 'expenses', label: 'Expenses', icon: FileText },
    { id: 'marketing', label: 'Marketing', icon: Megaphone },
    { id: 'entities', label: 'Management', icon: Users },
    { id: 'partners', label: 'Reports', icon: PieChart },
  ];

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return <Dashboard />;
      case 'sales':
        return <Sales />;
      case 'expenses':
        return <Expenses />;
      case 'marketing':
        return <Marketing />;
      case 'entities':
        return <Entities />;
      case 'partners':
        return <Reports />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <div className="min-h-screen bg-neutral-50 flex text-neutral-900" dir="auto">
      <Toaster position="top-right" />
      
      {/* Mobile sidebar overlay */}
      <AnimatePresence>
        {isSidebarOpen && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-slate-950/40 z-40 lg:hidden backdrop-blur-sm"
            onClick={toggleSidebar}
          />
        )}
      </AnimatePresence>

      {/* Sidebar */}
      <aside className={`
        fixed inset-y-0 start-0 z-50 w-72 bg-brand-navy-900 text-white transform transition-transform duration-300 ease-in-out lg:translate-x-0 lg:static lg:inset-0 shadow-2xl
        ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full rtl:translate-x-full'}
      `}>
        <div className="flex flex-col h-full">
          <div className="flex items-center justify-between h-24 px-8 border-b border-white/5">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-brand-gold-500/10 border border-brand-gold-500/20 flex items-center justify-center">
                <Building2 className="w-6 h-6 text-brand-gold-500" />
              </div>
              <span className="font-display font-bold text-2xl tracking-tight text-white">ASAS <span className="text-brand-gold-500">AGENCY</span></span>
            </div>
            <button onClick={toggleSidebar} className="lg:hidden text-slate-400 hover:text-white p-2" aria-label="Close menu">
              <X className="w-6 h-6" />
            </button>
          </div>
          
          <div className="p-6 border-b border-white/5">
            <div className="flex items-center gap-4 p-3 rounded-2xl bg-white/5 border border-white/5">
              <div className="w-12 h-12 rounded-xl bg-brand-gold-500 flex items-center justify-center text-brand-navy-900 font-bold text-lg shadow-lg shadow-brand-gold-500/20">
                {profile?.name?.charAt(0) || 'U'}
              </div>
              <div className="min-w-0">
                <p className="text-sm font-bold text-white truncate">{profile?.name}</p>
                <p className="text-[10px] text-brand-gold-500 uppercase tracking-widest font-bold mt-0.5">{profile?.role}</p>
              </div>
            </div>
          </div>

          <nav className="flex-1 p-6 space-y-2 overflow-y-auto">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    setActiveTab(item.id);
                    setIsSidebarOpen(false);
                  }}
                  className={`w-full flex items-center space-x-4 rtl:space-x-reverse px-5 py-4 rounded-2xl transition-all duration-300 group ${
                    isActive 
                      ? 'bg-brand-gold-500 text-brand-navy-900 shadow-xl shadow-brand-gold-500/20' 
                      : 'text-slate-400 hover:bg-white/5 hover:text-white'
                  }`}
                >
                  <Icon className={`w-5 h-5 transition-transform duration-300 ${isActive ? 'scale-110' : 'group-hover:scale-110'}`} />
                  <span className="font-bold text-sm tracking-wide">{item.label}</span>
                </button>
              );
            })}
          </nav>

          <div className="p-6 border-t border-white/5">
            <button
              onClick={signOut}
              className="w-full h-12 flex items-center space-x-4 rtl:space-x-reverse px-5 rounded-2xl text-slate-400 hover:bg-rose-500/10 hover:text-rose-400 transition-all duration-300 group"
            >
              <LogOut className="w-5 h-5 group-hover:-translate-x-1 transition-transform" />
              <span className="font-bold text-sm tracking-wide">Sign Out</span>
            </button>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-w-0 overflow-hidden">
        <header className="h-20 bg-white/80 backdrop-blur-xl border-b border-slate-200 flex items-center justify-between px-6 lg:px-10 sticky top-0 z-30">
          <div className="flex items-center gap-4">
            <button onClick={toggleSidebar} className="lg:hidden p-2 -ms-2 text-slate-600 hover:text-brand-navy-900 transition-colors" aria-label="Open menu">
              <Menu className="w-6 h-6" />
            </button>
            <h1 className="text-xl font-display font-bold text-brand-navy-900 tracking-tight">
              {navItems.find(i => i.id === activeTab)?.label}
            </h1>
          </div>
          
          <div className="flex items-center gap-4">
            <div className="hidden sm:flex flex-col items-end">
              <p className="text-xs font-bold text-brand-navy-900">{profile?.name}</p>
              <p className="text-[10px] text-slate-500 uppercase tracking-widest font-bold">{profile?.role}</p>
            </div>
            <div className="w-10 h-10 rounded-xl bg-slate-100 border border-slate-200 flex items-center justify-center text-brand-navy-900">
              <UserCircle className="w-6 h-6" />
            </div>
          </div>
        </header>

        <div className="flex-1 overflow-auto p-6 lg:p-10">
          <motion.div 
            key={activeTab}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, ease: "easeOut" }}
            className="max-w-7xl mx-auto"
          >
            {renderContent()}
          </motion.div>
        </div>
      </main>
    </div>
  );
}
