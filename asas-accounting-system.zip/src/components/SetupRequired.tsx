import React from 'react';
import { Database, Key, ArrowRight } from 'lucide-react';

export function SetupRequired() {
  return (
    <div className="min-h-screen bg-brand-navy-900 flex flex-col justify-center py-12 sm:px-6 lg:px-8 relative overflow-hidden" dir="auto">
      {/* Background decorative elements */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden z-0 pointer-events-none">
        <div className="absolute -top-40 -right-40 w-96 h-96 rounded-full bg-brand-gold-500/10 blur-3xl"></div>
        <div className="absolute top-40 -left-40 w-96 h-96 rounded-full bg-brand-gold-500/10 blur-3xl"></div>
      </div>

      <div className="sm:mx-auto sm:w-full sm:max-w-md relative z-10">
        <div className="flex justify-center">
          <div className="w-16 h-16 bg-brand-gold-500/10 border border-brand-gold-500/20 rounded-2xl flex items-center justify-center shadow-lg shadow-brand-gold-500/10">
            <Database className="w-8 h-8 text-brand-gold-500" />
          </div>
        </div>
        <h2 className="mt-6 text-center text-3xl font-display font-bold text-white tracking-tight">
          Database Connection Required
        </h2>
        <p className="mt-2 text-center text-sm text-slate-400 font-medium tracking-wide">
          Please configure your Supabase environment variables to continue.
        </p>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-xl relative z-10">
        <div className="bg-slate-800/50 backdrop-blur-xl border border-slate-700/50 rounded-3xl p-8 shadow-2xl shadow-black/50">
          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                <span className="flex items-center justify-center w-6 h-6 rounded-full bg-brand-gold-500/20 text-brand-gold-500 text-sm font-bold">1</span>
                Create a Supabase Project
              </h3>
              <p className="mt-2 text-sm text-slate-400 ms-8 font-medium">
                Go to <a href="https://supabase.com" target="_blank" rel="noopener noreferrer" className="text-brand-gold-500 hover:underline">supabase.com</a> and create a new project.
              </p>
            </div>

            <div>
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                <span className="flex items-center justify-center w-6 h-6 rounded-full bg-brand-gold-500/20 text-brand-gold-500 text-sm font-bold">2</span>
                Run the SQL Setup Script
              </h3>
              <p className="mt-2 text-sm text-slate-400 ms-8 font-medium">
                In your Supabase dashboard, go to the <strong>SQL Editor</strong> and run the contents of the <code>supabase/init.sql</code> file provided in this project.
              </p>
            </div>

            <div>
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                <span className="flex items-center justify-center w-6 h-6 rounded-full bg-brand-gold-500/20 text-brand-gold-500 text-sm font-bold">3</span>
                Add Environment Variables
              </h3>
              <p className="mt-2 text-sm text-slate-400 ms-8 mb-4 font-medium">
                In AI Studio, open the <strong>Secrets</strong> panel (or create a <code>.env</code> file locally) and add the following variables from your Supabase Project Settings &gt; API:
              </p>
              
              <div className="ms-8 bg-brand-navy-900/50 border border-slate-700/50 rounded-xl p-4 font-mono text-sm space-y-3">
                <div>
                  <div className="text-slate-500 mb-1 flex items-center gap-2 font-bold">
                    <Key className="w-3 h-3" /> VITE_SUPABASE_URL
                  </div>
                  <div className="text-semantic-success-400 break-all font-medium">https://your-project-id.supabase.co</div>
                </div>
                <div>
                  <div className="text-slate-500 mb-1 flex items-center gap-2 font-bold">
                    <Key className="w-3 h-3" /> VITE_SUPABASE_ANON_KEY
                  </div>
                  <div className="text-semantic-success-400 break-all font-medium">eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...</div>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-8 pt-6 border-t border-slate-700/50 flex justify-center">
            <button
              onClick={() => window.location.reload()}
              className="flex items-center gap-2 px-8 py-3 text-sm font-bold text-brand-navy-900 bg-brand-gold-500 hover:bg-brand-gold-400 rounded-xl transition-colors shadow-lg shadow-brand-gold-500/20 tracking-wide"
            >
              I've added the variables, reload app
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
