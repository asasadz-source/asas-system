import React from 'react';
import { TrendingUp, TrendingDown, Wallet, Receipt, ArrowUpRight, ArrowDownRight, Building2, UserCircle, Loader2, ArrowRight, Briefcase } from 'lucide-react';
import { formatCurrency } from '../utils';
import { useAuth } from '../context/AuthContext';
import { useDeals, useTransactions, usePartnersEquity } from '../hooks/useSupabaseData';
import { format, parseISO } from 'date-fns';
import { motion } from 'motion/react';

function DashboardCard({ children, className = "" }: { children: React.ReactNode, className?: string, key?: React.Key }) {
  return (
    <div className={`bg-white rounded-3xl shadow-sm border border-slate-200/60 p-6 lg:p-8 ${className}`}>
      {children}
    </div>
  );
}

export function Dashboard() {
  const { profile } = useAuth();
  const { data: deals, isLoading: dealsLoading } = useDeals();
  const { data: transactions, isLoading: transLoading } = useTransactions();
  const { data: equity, isLoading: equityLoading } = usePartnersEquity();

  if (dealsLoading || transLoading || (profile?.role === 'admin' && equityLoading)) {
    return (
      <div className="flex flex-col items-center justify-center p-20 space-y-4">
        <Loader2 className="w-10 h-10 animate-spin text-brand-gold-500" />
        <p className="text-slate-400 font-medium animate-pulse">Refining your data...</p>
      </div>
    );
  }

  const stats = [
    {
      title: 'Net Profit',
      value: equity?.net_profit || 0,
      icon: Wallet,
      trend: '+12.5%',
      color: 'text-emerald-600',
      bgColor: 'bg-emerald-50',
      adminOnly: true
    },
    {
      title: 'Total Revenue',
      value: equity?.total_revenue || 0,
      icon: TrendingUp,
      trend: '+8.2%',
      color: 'text-blue-600',
      bgColor: 'bg-blue-50',
      adminOnly: true
    },
    {
      title: 'Total Expenses',
      value: equity?.total_expenses || 0,
      icon: TrendingDown,
      trend: '-2.4%',
      color: 'text-rose-600',
      bgColor: 'bg-rose-50',
      adminOnly: true
    },
    {
      title: 'Pending Commissions',
      value: 0, // Placeholder until we have a proper calculation for new schema
      icon: Receipt,
      trend: 'Active',
      color: 'text-brand-gold-500',
      bgColor: 'bg-brand-gold-500/5',
      adminOnly: false
    }
  ];

  const filteredStats = stats.filter(s => !s.adminOnly || profile?.role === 'admin');

  return (
    <div className="space-y-10 pb-10">
      {/* Welcome Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h2 className="text-3xl lg:text-4xl font-display font-bold text-brand-navy-900 tracking-tight">
            Welcome back, <span className="text-brand-gold-500">{profile?.name?.split(' ')[0]}</span>
          </h2>
          <p className="text-slate-500 mt-2 font-medium">Here's what's happening with ASAS Agency today.</p>
        </div>
        <div className="flex items-center gap-2 text-sm font-bold text-slate-400 bg-white px-4 py-2 rounded-full shadow-sm border border-slate-200 w-fit">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
          LIVE UPDATES
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {filteredStats.map((stat, index) => (
          <DashboardCard key={index} className="group hover:border-brand-gold-500/30 transition-all duration-300">
            <div className="flex items-center justify-between mb-6">
              <div className={`p-3 rounded-2xl ${stat.bgColor} border border-black/5`}>
                <stat.icon className={`w-6 h-6 ${stat.color}`} />
              </div>
              <span className={`text-[10px] uppercase tracking-widest font-bold px-2.5 py-1 rounded-full border ${
                stat.trend.startsWith('+') ? 'bg-emerald-50 text-emerald-600 border-emerald-100' : 
                stat.trend.startsWith('-') ? 'bg-rose-50 text-rose-600 border-rose-100' : 
                'bg-slate-50 text-slate-500 border-slate-100'
              }`}>
                {stat.trend}
              </span>
            </div>
            <p className="text-slate-500 text-[10px] uppercase tracking-[0.2em] font-bold mb-1">{stat.title}</p>
            <h3 className="text-3xl font-bold text-brand-navy-900 tracking-tight">
              {formatCurrency(stat.value)}
            </h3>
          </DashboardCard>
        ))}
      </div>

      {profile?.role === 'admin' && equity && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <DashboardCard className="relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-brand-gold-500/5 rounded-full -mr-16 -mt-16 blur-3xl"></div>
            <div className="flex items-center justify-between mb-10">
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-center text-brand-gold-500 shadow-sm">
                  <UserCircle className="w-8 h-8" />
                </div>
                <div>
                  <h3 className="text-xl font-display font-bold text-brand-navy-900">Hammou.HS</h3>
                  <p className="text-[10px] text-slate-400 uppercase tracking-widest font-bold mt-1">Founding Partner</p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-[10px] text-slate-400 uppercase tracking-widest mb-1 font-bold">Ownership</p>
                <p className="text-xl font-bold text-brand-navy-900">65.0%</p>
              </div>
            </div>
            <div className="space-y-8">
              <div className="flex justify-between items-end">
                <span className="text-slate-500 text-xs uppercase tracking-widest font-bold">Available Equity</span>
                <span className="text-4xl font-bold text-emerald-600 tracking-tighter">{formatCurrency(equity.hammou_balance)}</span>
              </div>
              <div className="relative w-full bg-slate-100 h-2.5 rounded-full overflow-hidden">
                <motion.div 
                  initial={{ width: 0 }}
                  animate={{ width: '65%' }}
                  transition={{ duration: 1.5, ease: "easeOut" }}
                  className="absolute inset-y-0 left-0 bg-emerald-500 h-full rounded-full"
                ></motion.div>
              </div>
            </div>
          </DashboardCard>

          <DashboardCard className="relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-brand-gold-500/5 rounded-full -mr-16 -mt-16 blur-3xl"></div>
            <div className="flex items-center justify-between mb-10">
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-center text-brand-gold-500 shadow-sm">
                  <UserCircle className="w-8 h-8" />
                </div>
                <div>
                  <h3 className="text-xl font-display font-bold text-brand-navy-900">Redouane.AG</h3>
                  <p className="text-[10px] text-slate-400 uppercase tracking-widest font-bold mt-1">Managing Partner</p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-[10px] text-slate-400 uppercase tracking-widest mb-1 font-bold">Ownership</p>
                <p className="text-xl font-bold text-brand-navy-900">35.0%</p>
              </div>
            </div>
            <div className="space-y-8">
              <div className="flex justify-between items-end">
                <span className="text-slate-500 text-xs uppercase tracking-widest font-bold">Available Equity</span>
                <span className="text-4xl font-bold text-emerald-600 tracking-tighter">{formatCurrency(equity.redouane_balance)}</span>
              </div>
              <div className="relative w-full bg-slate-100 h-2.5 rounded-full overflow-hidden">
                <motion.div 
                  initial={{ width: 0 }}
                  animate={{ width: '35%' }}
                  transition={{ duration: 1.5, ease: "easeOut" }}
                  className="absolute inset-y-0 left-0 bg-emerald-500 h-full rounded-full"
                ></motion.div>
              </div>
            </div>
          </DashboardCard>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
        {/* Recent Sales */}
        <div className="space-y-6">
          <div className="flex items-center justify-between px-2">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-white shadow-sm border border-slate-200 flex items-center justify-center">
                <Building2 className="w-5 h-5 text-brand-gold-500" />
              </div>
              <h3 className="text-xl font-display font-bold text-brand-navy-900">Recent Sales</h3>
            </div>
            <button className="text-[10px] uppercase tracking-[0.2em] text-brand-gold-500 hover:text-brand-gold-400 font-bold flex items-center gap-2 transition-colors">
              View All <ArrowRight className="w-3 h-3" />
            </button>
          </div>
          
          <div className="space-y-4">
            {deals?.slice(0, 5).map((deal) => (
              <DashboardCard key={deal.id} className="!p-5 hover:translate-x-1 transition-transform duration-300">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-2xl bg-slate-50 flex items-center justify-center text-slate-400 group-hover:text-brand-gold-500 transition-colors">
                      <Briefcase className="w-6 h-6" />
                    </div>
                    <div>
                      <p className="font-bold text-brand-navy-900 text-sm">{(deal as any).property?.location || 'Unknown Project'}</p>
                      <p className="text-xs text-slate-400 mt-0.5 font-medium">{(deal as any).buyer?.name || 'Unknown Client'} • {(deal as any).property?.type}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-brand-navy-900">{formatCurrency(deal.total_amount || 0)}</p>
                    <div className="mt-1">
                      <span className={`text-[10px] font-bold uppercase tracking-widest px-2 py-0.5 rounded-full border ${
                        deal.status === 'finalized' 
                          ? 'bg-emerald-50 text-emerald-600 border-emerald-100' 
                          : 'bg-brand-gold-500/5 text-brand-gold-500 border-brand-gold-500/10'
                      }`}>
                        {deal.status}
                      </span>
                    </div>
                  </div>
                </div>
              </DashboardCard>
            ))}
            {(!deals || deals.length === 0) && (
              <div className="text-center py-12 bg-white/50 rounded-3xl border border-dashed border-slate-300">
                <p className="text-slate-400 font-medium">No recent sales found.</p>
              </div>
            )}
          </div>
        </div>

        {/* Recent Transactions */}
        <div className="space-y-6">
          <div className="flex items-center justify-between px-2">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-white shadow-sm border border-slate-200 flex items-center justify-center">
                <Receipt className="w-5 h-5 text-brand-gold-500" />
              </div>
              <h3 className="text-xl font-display font-bold text-brand-navy-900">Recent Transactions</h3>
            </div>
            <button className="text-[10px] uppercase tracking-[0.2em] text-brand-gold-500 hover:text-brand-gold-400 font-bold flex items-center gap-2 transition-colors">
              View All <ArrowRight className="w-3 h-3" />
            </button>
          </div>

          <div className="space-y-4">
            {transactions?.slice(0, 5).map((trans) => (
              <DashboardCard key={trans.id} className="!p-5 hover:translate-x-1 transition-transform duration-300">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className={`w-12 h-12 rounded-2xl flex items-center justify-center ${trans.amount > 0 ? 'bg-emerald-50 text-emerald-600' : 'bg-rose-50 text-rose-600'}`}>
                      {trans.amount > 0 ? <ArrowUpRight className="w-6 h-6" /> : <ArrowDownRight className="w-6 h-6" />}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <p className="font-bold text-brand-navy-900 text-[10px] uppercase tracking-widest">{(trans as any).type?.replace('_', ' ') || (trans as any).category}</p>
                      </div>
                      <p className="text-[10px] text-slate-400 mt-1 font-medium">
                        {format(parseISO(trans.created_at), 'dd MMM')} • {(trans as any).description || 'No description'}
                      </p>
                    </div>
                  </div>
                  <p className={`font-bold text-lg ${trans.type === 'PAYMENT' ? 'text-emerald-600' : 'text-rose-600'}`}>
                    {formatCurrency(trans.amount)}
                  </p>
                </div>
              </DashboardCard>
            ))}
            {(!transactions || transactions.length === 0) && (
              <div className="text-center py-12 bg-white/50 rounded-3xl border border-dashed border-slate-300">
                <p className="text-slate-400 font-medium">No recent transactions recorded.</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

