import React, { useState } from 'react';
import { Plus, Edit, Trash2, Users, UserCircle, Home, Loader2, Building2 } from 'lucide-react';
import { useUsers, useProperties } from '../hooks/useSupabaseData';
import { supabase } from '../lib/supabase';
import { useQueryClient, useMutation } from '@tanstack/react-query';
import { toast } from 'react-hot-toast';
import { formatCurrency } from '../utils';

export function Entities() {
  const [activeTab, setActiveTab] = useState<'clients' | 'agents' | 'properties'>('clients');

  const tabs = [
    { id: 'clients', label: 'Clients', icon: Users },
    { id: 'agents', label: 'Sales Agents', icon: UserCircle },
    { id: 'properties', label: 'Properties', icon: Building2 },
  ] as const;

  return (
    <div className="space-y-8 pb-10">
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-6">
        <div>
          <h2 className="text-3xl lg:text-4xl font-display font-bold text-brand-navy-900 tracking-tight">Entities Database</h2>
          <p className="text-slate-500 font-medium mt-1">Manage your core business relationships and assets</p>
        </div>
      </div>

      <div className="flex space-x-2 bg-white p-1.5 rounded-2xl border border-slate-200 shadow-sm overflow-x-auto no-scrollbar">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center space-x-2 px-6 py-3 rounded-xl transition-all whitespace-nowrap font-bold text-sm tracking-wide ${
                isActive 
                  ? 'bg-brand-gold-500 text-brand-navy-900 shadow-lg shadow-brand-gold-500/20' 
                  : 'text-slate-400 hover:text-brand-navy-900 hover:bg-slate-50'
              }`}
            >
              <Icon className={`w-4 h-4 ${isActive ? 'text-brand-navy-900' : 'text-slate-400'}`} />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      <div className="bg-white p-2 md:p-8 rounded-[2.5rem] border border-slate-200 shadow-sm">
        {activeTab === 'clients' && <ClientsManager />}
        {activeTab === 'agents' && <AgentsManager />}
        {activeTab === 'properties' && <PropertiesManager />}
      </div>
    </div>
  );
}

function ClientsManager() {
  const queryClient = useQueryClient();
  const { data: clients, isLoading } = useUsers('client');
  const [isAdding, setIsAdding] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formData, setFormData] = useState({ name: '', phone: '', email: '' });

  const mutation = useMutation({
    mutationFn: async (data: any) => {
      const payload = { ...data, role: 'client' };
      if (editingId) {
        const { error } = await supabase.from('users').update(payload).eq('id', editingId);
        if (error) throw error;
      } else {
        const { error } = await supabase.from('users').insert([payload]);
        if (error) throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['users', 'client'] });
      setIsAdding(false);
      setEditingId(null);
      setFormData({ name: '', phone: '', email: '' });
      toast.success(editingId ? 'Client updated' : 'Client added');
    },
    onError: (error: any) => toast.error(error.message),
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from('users').delete().eq('id', id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['users', 'client'] });
      toast.success('Client deleted');
    },
  });

  if (isLoading) return (
    <div className="flex flex-col items-center justify-center p-20 space-y-4">
      <Loader2 className="w-10 h-10 animate-spin text-brand-gold-500" />
      <p className="text-slate-400 font-medium animate-pulse">Loading clients...</p>
    </div>
  );

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center px-4 md:px-0">
        <h2 className="text-2xl font-display font-bold text-brand-navy-900">Clients</h2>
        <button 
          onClick={() => { 
            setIsAdding(true); 
            setEditingId(null); 
            setFormData({ name: '', phone: '', email: '' }); 
          }} 
          className="flex items-center space-x-2 bg-brand-gold text-sidebar-dark px-6 py-3 rounded-2xl hover:bg-brand-gold/90 font-bold transition-all shadow-lg shadow-brand-gold/20 text-sm tracking-wide"
        >
          <Plus className="w-4 h-4" />
          <span>ADD CLIENT</span>
        </button>
      </div>

      {isAdding && (
        <form onSubmit={(e) => { e.preventDefault(); mutation.mutate(formData); }} className="bg-slate-50 p-8 rounded-3xl border border-slate-200 grid grid-cols-1 md:grid-cols-2 gap-6 mx-4 md:mx-0">
          <div className="space-y-2">
            <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest ml-1">Full Name</label>
            <input required type="text" value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} className="w-full p-3.5 bg-white border border-slate-200 rounded-2xl text-sidebar-dark focus:outline-none focus:ring-2 focus:ring-brand-gold/20 focus:border-brand-gold transition-all" />
          </div>
          <div className="space-y-2">
            <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest ml-1">Phone</label>
            <input type="text" value={formData.phone} onChange={e => setFormData({...formData, phone: e.target.value})} className="w-full p-3.5 bg-white border border-slate-200 rounded-2xl text-sidebar-dark focus:outline-none focus:ring-2 focus:ring-brand-gold/20 focus:border-brand-gold transition-all" />
          </div>
          <div className="space-y-2 md:col-span-2">
            <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest ml-1">Email</label>
            <input required type="email" value={formData.email} onChange={e => setFormData({...formData, email: e.target.value})} className="w-full p-3.5 bg-white border border-slate-200 rounded-2xl text-sidebar-dark focus:outline-none focus:ring-2 focus:ring-brand-gold/20 focus:border-brand-gold transition-all" />
          </div>
          <div className="md:col-span-2 flex justify-end space-x-4 pt-4">
            <button type="button" onClick={() => setIsAdding(false)} className="px-6 py-3 text-slate-400 hover:text-sidebar-dark font-bold text-sm transition-colors">CANCEL</button>
            <button type="submit" disabled={mutation.isPending} className="px-8 py-3 bg-brand-navy-900 text-white rounded-2xl hover:bg-slate-800 font-bold disabled:opacity-50 text-sm tracking-wide transition-all shadow-lg shadow-slate-200">
              {mutation.isPending ? 'SAVING...' : 'SAVE CLIENT'}
            </button>
          </div>
        </form>
      )}

      {/* Desktop Table View */}
      <div className="hidden md:block bg-white rounded-3xl border border-slate-100 overflow-hidden">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-slate-50/50 text-[10px] text-slate-400 uppercase tracking-[0.2em] font-bold">
              <th className="px-8 py-5">Name</th>
              <th className="px-8 py-5">Contact</th>
              <th className="px-8 py-5 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-50">
            {clients?.map(client => (
              <tr key={client.id} className="hover:bg-slate-50/50 transition-colors group">
                <td className="px-8 py-6">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center text-slate-400 group-hover:bg-brand-gold group-hover:text-white transition-all duration-300">
                      <UserCircle className="w-6 h-6" />
                    </div>
                    <span className="font-bold text-sidebar-dark">{client.name}</span>
                  </div>
                </td>
                <td className="px-8 py-6">
                  <div className="text-sm font-bold text-sidebar-dark">{client.phone || 'N/A'}</div>
                  <div className="text-xs text-slate-400 font-medium">{client.email}</div>
                </td>
                <td className="px-8 py-6 text-right">
                  <div className="flex items-center justify-end gap-2 opacity-0 group-hover:opacity-100 transition-all">
                    <button onClick={() => { setFormData({ name: client.name, phone: client.phone || '', email: client.email || '' }); setEditingId(client.id); setIsAdding(true); }} className="w-10 h-10 flex items-center justify-center text-slate-400 hover:text-brand-gold-500 hover:bg-brand-gold-500/5 rounded-xl transition-all"><Edit className="w-4 h-4" /></button>
                    <button onClick={() => { if(confirm('Are you sure?')) deleteMutation.mutate(client.id); }} className="w-10 h-10 flex items-center justify-center text-slate-400 hover:text-rose-500 hover:bg-rose-50 rounded-xl transition-all"><Trash2 className="w-4 h-4" /></button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Mobile Card View */}
      <div className="md:hidden space-y-4 px-4">
        {clients?.map(client => (
          <div key={client.id} className="bg-slate-50 p-6 rounded-3xl border border-slate-100 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-white flex items-center justify-center text-brand-gold border border-slate-100">
                  <UserCircle className="w-6 h-6" />
                </div>
                <span className="font-bold text-sidebar-dark">{client.name}</span>
              </div>
              <div className="flex gap-1">
                <button onClick={() => { setFormData({ name: client.name, phone: client.phone || '', email: client.email || '' }); setEditingId(client.id); setIsAdding(true); }} className="p-2 text-slate-400 hover:text-brand-gold-500"><Edit className="w-4 h-4" /></button>
                <button onClick={() => { if(confirm('Are you sure?')) deleteMutation.mutate(client.id); }} className="p-2 text-slate-400 hover:text-rose-500"><Trash2 className="w-4 h-4" /></button>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Phone</p>
                <p className="text-sm font-bold text-sidebar-dark">{client.phone || 'N/A'}</p>
              </div>
              <div>
                <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Email</p>
                <p className="text-sm font-bold text-sidebar-dark">{client.email}</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function AgentsManager() {
  const queryClient = useQueryClient();
  const { data: agents, isLoading } = useUsers('agent');
  const [isAdding, setIsAdding] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formData, setFormData] = useState({ name: '', phone: '', email: '' });

  const mutation = useMutation({
    mutationFn: async (data: any) => {
      const payload = { ...data, role: 'agent' };
      if (editingId) {
        const { error } = await supabase.from('users').update(payload).eq('id', editingId);
        if (error) throw error;
      } else {
        const { error } = await supabase.from('users').insert([payload]);
        if (error) throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['users', 'agent'] });
      setIsAdding(false);
      setEditingId(null);
      setFormData({ name: '', phone: '', email: '' });
      toast.success(editingId ? 'Agent updated' : 'Agent added');
    },
    onError: (error: any) => toast.error(error.message),
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from('users').delete().eq('id', id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['users', 'agent'] });
      toast.success('Agent deleted');
    },
  });

  if (isLoading) return (
    <div className="flex flex-col items-center justify-center p-20 space-y-4">
      <Loader2 className="w-10 h-10 animate-spin text-brand-gold" />
      <p className="text-slate-400 font-medium animate-pulse">Loading agents...</p>
    </div>
  );

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center px-4 md:px-0">
        <h2 className="text-2xl font-display font-bold text-sidebar-dark">Sales Agents</h2>
        <button 
          onClick={() => { 
            setIsAdding(true); 
            setEditingId(null); 
            setFormData({ name: '', phone: '', email: '' }); 
          }} 
          className="flex items-center space-x-2 bg-brand-gold text-sidebar-dark px-6 py-3 rounded-2xl hover:bg-brand-gold/90 font-bold transition-all shadow-lg shadow-brand-gold/20 text-sm tracking-wide"
        >
          <Plus className="w-4 h-4" />
          <span>ADD AGENT</span>
        </button>
      </div>

      {isAdding && (
        <form onSubmit={(e) => { e.preventDefault(); mutation.mutate(formData); }} className="bg-slate-50 p-8 rounded-3xl border border-slate-200 grid grid-cols-1 md:grid-cols-2 gap-6 mx-4 md:mx-0">
          <div className="space-y-2">
            <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest ml-1">Full Name</label>
            <input required type="text" value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} className="w-full p-3.5 bg-white border border-slate-200 rounded-2xl text-sidebar-dark focus:outline-none focus:ring-2 focus:ring-brand-gold/20 focus:border-brand-gold transition-all" />
          </div>
          <div className="space-y-2">
            <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest ml-1">Phone</label>
            <input type="text" value={formData.phone} onChange={e => setFormData({...formData, phone: e.target.value})} className="w-full p-3.5 bg-white border border-slate-200 rounded-2xl text-sidebar-dark focus:outline-none focus:ring-2 focus:ring-brand-gold/20 focus:border-brand-gold transition-all" />
          </div>
          <div className="space-y-2 md:col-span-2">
            <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest ml-1">Email</label>
            <input required type="email" value={formData.email} onChange={e => setFormData({...formData, email: e.target.value})} className="w-full p-3.5 bg-white border border-slate-200 rounded-2xl text-sidebar-dark focus:outline-none focus:ring-2 focus:ring-brand-gold/20 focus:border-brand-gold transition-all" />
          </div>
          <div className="md:col-span-2 flex justify-end space-x-4 pt-4">
            <button type="button" onClick={() => setIsAdding(false)} className="px-6 py-3 text-slate-400 hover:text-sidebar-dark font-bold text-sm transition-colors">CANCEL</button>
            <button type="submit" disabled={mutation.isPending} className="px-8 py-3 bg-sidebar-dark text-white rounded-2xl hover:bg-slate-800 font-bold disabled:opacity-50 text-sm tracking-wide transition-all shadow-lg shadow-slate-200">
              {mutation.isPending ? 'SAVING...' : 'SAVE AGENT'}
            </button>
          </div>
        </form>
      )}

      <div className="bg-white rounded-3xl border border-slate-100 overflow-hidden hidden md:block">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-slate-50/50 text-[10px] text-slate-400 uppercase tracking-[0.2em] font-bold">
              <th className="px-8 py-5">Agent Name</th>
              <th className="px-8 py-5">Contact</th>
              <th className="px-8 py-5">Joined</th>
              <th className="px-8 py-5 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-50">
            {agents?.map(agent => (
              <tr key={agent.id} className="hover:bg-slate-50/50 transition-colors group">
                <td className="px-8 py-6">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center text-slate-400 group-hover:bg-brand-gold group-hover:text-white transition-all duration-300">
                      <UserCircle className="w-6 h-6" />
                    </div>
                    <span className="font-bold text-sidebar-dark">{agent.name}</span>
                  </div>
                </td>
                <td className="px-8 py-6">
                  <div className="text-sm font-bold text-sidebar-dark">{agent.phone || 'N/A'}</div>
                  <div className="text-xs text-slate-400 font-medium">{agent.email}</div>
                </td>
                <td className="px-8 py-6 text-sm text-slate-500 font-medium">
                  {new Date(agent.created_at).toLocaleDateString(undefined, { year: 'numeric', month: 'long', day: 'numeric' })}
                </td>
                <td className="px-8 py-6 text-right">
                  <div className="flex items-center justify-end gap-2 opacity-0 group-hover:opacity-100 transition-all">
                    <button onClick={() => { setFormData({ name: agent.name, phone: agent.phone || '', email: agent.email || '' }); setEditingId(agent.id); setIsAdding(true); }} className="w-10 h-10 flex items-center justify-center text-slate-400 hover:text-brand-gold-500 hover:bg-brand-gold-500/5 rounded-xl transition-all"><Edit className="w-4 h-4" /></button>
                    <button onClick={() => { if(confirm('Are you sure?')) deleteMutation.mutate(agent.id); }} className="w-10 h-10 flex items-center justify-center text-slate-400 hover:text-rose-500 hover:bg-rose-50 rounded-xl transition-all"><Trash2 className="w-4 h-4" /></button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="md:hidden space-y-4 px-4">
        {agents?.map(agent => (
          <div key={agent.id} className="bg-slate-50 p-6 rounded-3xl border border-slate-100 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-white flex items-center justify-center text-brand-gold border border-slate-100">
                  <UserCircle className="w-6 h-6" />
                </div>
                <span className="font-bold text-sidebar-dark">{agent.name}</span>
              </div>
              <div className="flex gap-1">
                <button onClick={() => { setFormData({ name: agent.name, phone: agent.phone || '', email: agent.email || '' }); setEditingId(agent.id); setIsAdding(true); }} className="p-2 text-slate-400 hover:text-brand-gold-500"><Edit className="w-4 h-4" /></button>
                <button onClick={() => { if(confirm('Are you sure?')) deleteMutation.mutate(agent.id); }} className="p-2 text-slate-400 hover:text-rose-500"><Trash2 className="w-4 h-4" /></button>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Phone</p>
                <p className="text-sm font-bold text-sidebar-dark">{agent.phone || 'N/A'}</p>
              </div>
              <div>
                <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Joined</p>
                <p className="text-sm font-bold text-sidebar-dark">{new Date(agent.created_at).toLocaleDateString()}</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function PropertiesManager() {
  const queryClient = useQueryClient();
  const { data: properties, isLoading } = useProperties();
  const [isAdding, setIsAdding] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formData, setFormData] = useState({ type: 'apartment', location: '', price: 0, status: 'available' });

  const mutation = useMutation({
    mutationFn: async (data: any) => {
      if (editingId) {
        const { error } = await supabase.from('properties').update(data).eq('id', editingId);
        if (error) throw error;
      } else {
        const { error } = await supabase.from('properties').insert([data]);
        if (error) throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['properties'] });
      setIsAdding(false);
      setEditingId(null);
      setFormData({ type: 'apartment', location: '', price: 0, status: 'available' });
      toast.success(editingId ? 'Property updated' : 'Property added');
    },
    onError: (error: any) => toast.error(error.message),
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from('properties').delete().eq('id', id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['properties'] });
      toast.success('Property deleted');
    },
  });

  if (isLoading) return (
    <div className="flex flex-col items-center justify-center p-20 space-y-4">
      <Loader2 className="w-10 h-10 animate-spin text-brand-gold" />
      <p className="text-slate-400 font-medium animate-pulse">Loading properties...</p>
    </div>
  );

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center px-4 md:px-0">
        <h2 className="text-2xl font-display font-bold text-sidebar-dark">Properties</h2>
        <button 
          onClick={() => { 
            setIsAdding(true); 
            setEditingId(null); 
            setFormData({ type: 'apartment', location: '', price: 0, status: 'available' }); 
          }} 
          className="flex items-center space-x-2 bg-brand-gold text-sidebar-dark px-6 py-3 rounded-2xl hover:bg-brand-gold/90 font-bold transition-all shadow-lg shadow-brand-gold/20 text-sm tracking-wide"
        >
          <Plus className="w-4 h-4" />
          <span>ADD PROPERTY</span>
        </button>
      </div>

      {isAdding && (
        <form onSubmit={(e) => { e.preventDefault(); mutation.mutate(formData); }} className="bg-slate-50 p-8 rounded-3xl border border-slate-200 grid grid-cols-1 md:grid-cols-2 gap-6 mx-4 md:mx-0">
          <div className="space-y-2">
            <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest ml-1">Type</label>
            <select required value={formData.type} onChange={e => setFormData({...formData, type: e.target.value})} className="w-full p-3.5 bg-white border border-slate-200 rounded-2xl text-sidebar-dark focus:outline-none focus:ring-2 focus:ring-brand-gold/20 focus:border-brand-gold transition-all appearance-none">
              <option value="apartment">Apartment</option>
              <option value="villa">Villa</option>
              <option value="commercial">Commercial</option>
            </select>
          </div>
          <div className="space-y-2">
            <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest ml-1">Status</label>
            <select required value={formData.status} onChange={e => setFormData({...formData, status: e.target.value})} className="w-full p-3.5 bg-white border border-slate-200 rounded-2xl text-sidebar-dark focus:outline-none focus:ring-2 focus:ring-brand-gold/20 focus:border-brand-gold transition-all appearance-none">
              <option value="available">Available</option>
              <option value="reserved">Reserved</option>
              <option value="sold">Sold</option>
            </select>
          </div>
          <div className="space-y-2">
            <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest ml-1">Location</label>
            <input required type="text" value={formData.location} onChange={e => setFormData({...formData, location: e.target.value})} className="w-full p-3.5 bg-white border border-slate-200 rounded-2xl text-sidebar-dark focus:outline-none focus:ring-2 focus:ring-brand-gold/20 focus:border-brand-gold transition-all" />
          </div>
          <div className="space-y-2">
            <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest ml-1">Price (DZD)</label>
            <input required type="number" min="0" step="0.01" value={formData.price} onChange={e => setFormData({...formData, price: parseFloat(e.target.value)})} className="w-full p-3.5 bg-white border border-slate-200 rounded-2xl text-sidebar-dark focus:outline-none focus:ring-2 focus:ring-brand-gold/20 focus:border-brand-gold transition-all" />
          </div>
          <div className="md:col-span-2 flex justify-end space-x-4 pt-4">
            <button type="button" onClick={() => setIsAdding(false)} className="px-6 py-3 text-slate-400 hover:text-sidebar-dark font-bold text-sm transition-colors">CANCEL</button>
            <button type="submit" disabled={mutation.isPending} className="px-8 py-3 bg-sidebar-dark text-white rounded-2xl hover:bg-slate-800 font-bold disabled:opacity-50 text-sm tracking-wide transition-all shadow-lg shadow-slate-200">
              {mutation.isPending ? 'SAVING...' : 'SAVE PROPERTY'}
            </button>
          </div>
        </form>
      )}

      {/* Desktop Table View */}
      <div className="hidden md:block bg-white rounded-3xl border border-slate-100 overflow-hidden">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-slate-50/50 text-[10px] text-slate-400 uppercase tracking-[0.2em] font-bold">
              <th className="px-8 py-5">Location</th>
              <th className="px-8 py-5">Type</th>
              <th className="px-8 py-5">Price</th>
              <th className="px-8 py-5">Status</th>
              <th className="px-8 py-5 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-50">
            {properties?.map(property => (
              <tr key={property.id} className="hover:bg-slate-50/50 transition-colors group">
                <td className="px-8 py-6">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-slate-100 flex items-center justify-center text-brand-gold group-hover:bg-brand-gold group-hover:text-white transition-all duration-300">
                      <Home className="w-6 h-6" />
                    </div>
                    <span className="font-bold text-sidebar-dark">{property.location}</span>
                  </div>
                </td>
                <td className="px-8 py-6">
                  <span className="text-sm font-bold text-sidebar-dark capitalize">{property.type}</span>
                </td>
                <td className="px-8 py-6 text-sm text-slate-500 font-medium">{formatCurrency(property.price)}</td>
                <td className="px-8 py-6">
                  <span className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest ${
                    property.status === 'available' ? 'bg-emerald-50 text-emerald-600' :
                    property.status === 'reserved' ? 'bg-amber-50 text-amber-600' :
                    'bg-rose-50 text-rose-600'
                  }`}>
                    {property.status}
                  </span>
                </td>
                <td className="px-8 py-6 text-right">
                  <div className="flex items-center justify-end gap-2 opacity-0 group-hover:opacity-100 transition-all">
                    <button onClick={() => { setFormData({ type: property.type, location: property.location, price: property.price, status: property.status }); setEditingId(property.id); setIsAdding(true); }} className="w-10 h-10 flex items-center justify-center text-slate-400 hover:text-brand-gold hover:bg-brand-gold/5 rounded-xl transition-all"><Edit className="w-4 h-4" /></button>
                    <button onClick={() => { if(confirm('Are you sure?')) deleteMutation.mutate(property.id); }} className="w-10 h-10 flex items-center justify-center text-slate-400 hover:text-rose-500 hover:bg-rose-50 rounded-xl transition-all"><Trash2 className="w-4 h-4" /></button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Mobile Card View */}
      <div className="md:hidden space-y-4 px-4">
        {properties?.map(property => (
          <div key={property.id} className="bg-slate-50 p-6 rounded-3xl border border-slate-100 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-white flex items-center justify-center text-brand-gold border border-slate-100">
                  <Home className="w-6 h-6" />
                </div>
                <span className="font-bold text-sidebar-dark">{property.location}</span>
              </div>
              <div className="flex gap-1">
                <button onClick={() => { setFormData({ type: property.type, location: property.location, price: property.price, status: property.status }); setEditingId(property.id); setIsAdding(true); }} className="p-2 text-slate-400 hover:text-brand-gold"><Edit className="w-4 h-4" /></button>
                <button onClick={() => { if(confirm('Are you sure?')) deleteMutation.mutate(property.id); }} className="p-2 text-slate-400 hover:text-rose-500"><Trash2 className="w-4 h-4" /></button>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Type</p>
                <p className="text-sm font-bold text-sidebar-dark capitalize">{property.type}</p>
              </div>
              <div>
                <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Status</p>
                <span className={`inline-block mt-1 px-2 py-0.5 rounded-full text-[9px] font-bold uppercase tracking-widest ${
                    property.status === 'available' ? 'bg-emerald-50 text-emerald-600' :
                    property.status === 'reserved' ? 'bg-amber-50 text-amber-600' :
                    'bg-rose-50 text-rose-600'
                  }`}>
                    {property.status}
                  </span>
              </div>
              <div className="col-span-2">
                <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Price</p>
                <p className="text-sm font-bold text-sidebar-dark">{formatCurrency(property.price)}</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
