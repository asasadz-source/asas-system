import React, { useState } from 'react';
import { useCampaigns, useDeals } from '../hooks/useSupabaseData';
import { formatCurrency } from '../utils';
import { Plus, Edit, Trash2, X, TrendingUp, Loader2, Megaphone, Receipt } from 'lucide-react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '../lib/supabase';
import toast from 'react-hot-toast';
import { MarketingCampaign } from '../types/supabase';

export function Marketing() {
  const queryClient = useQueryClient();
  const [isAdding, setIsAdding] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [newCampaign, setNewCampaign] = useState<Partial<MarketingCampaign>>({
    name: '',
    platform: 'Facebook',
    budget: 0,
    leads_generated: 0,
    appointments_set: 0,
    start_date: new Date().toISOString().split('T')[0]
  });

  const { data: campaigns, isLoading: campaignsLoading } = useCampaigns();
  const { data: deals } = useDeals();

  const saveMutation = useMutation({
    mutationFn: async (campaign: Partial<MarketingCampaign>) => {
      if (editingId) {
        const { error } = await supabase
          .from('marketing_campaigns')
          .update(campaign)
          .eq('id', editingId);
        if (error) throw error;
      } else {
        const { error } = await supabase
          .from('marketing_campaigns')
          .insert([campaign as any]);
        if (error) throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['campaigns'] });
      toast.success(editingId ? 'Campaign updated' : 'Campaign created');
      setIsAdding(false);
      setEditingId(null);
      setNewCampaign({
        name: '',
        platform: 'Facebook',
        budget: 0,
        leads_generated: 0,
        appointments_set: 0,
        start_date: new Date().toISOString().split('T')[0]
      });
    },
    onError: (error: any) => {
      toast.error(error.message || 'Failed to save campaign');
    }
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from('marketing_campaigns')
        .delete()
        .eq('id', id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['campaigns'] });
      toast.success('Campaign deleted');
    },
    onError: (error: any) => {
      toast.error(error.message || 'Failed to delete campaign');
    }
  });

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    saveMutation.mutate(newCampaign);
  };

  if (campaignsLoading) {
    return (
      <div className="flex flex-col items-center justify-center p-20 space-y-4">
        <Loader2 className="w-10 h-10 animate-spin text-brand-gold" />
        <p className="text-slate-400 font-medium animate-pulse">Loading campaigns...</p>
      </div>
    );
  }

  return (
    <div className="space-y-8 pb-10">
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-6">
        <div>
          <h2 className="text-3xl lg:text-4xl font-display font-bold text-sidebar-dark tracking-tight">Marketing Campaigns</h2>
          <p className="text-slate-500 font-medium mt-1">Track ad performance, leads, and marketing ROI</p>
        </div>
        <button 
          onClick={() => { 
            setIsAdding(true); 
            setEditingId(null); 
            setNewCampaign({ name: '', platform: 'Facebook', budget: 0, leads_generated: 0, appointments_set: 0 }); 
          }} 
          className="flex items-center space-x-2 bg-brand-gold text-sidebar-dark px-8 py-3.5 rounded-2xl hover:bg-brand-gold/90 font-bold transition-all shadow-xl shadow-brand-gold/20 text-sm tracking-wide w-full lg:w-auto justify-center"
        >
          <Plus className="w-5 h-5" />
          <span>ADD CAMPAIGN</span>
        </button>
      </div>

      {isAdding && (
        <form onSubmit={handleSave} className="bg-white p-8 rounded-[2.5rem] shadow-sm border border-slate-200 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <div className="flex justify-between items-center md:col-span-2 lg:col-span-3 mb-2 border-b border-slate-100 pb-6">
            <h3 className="text-2xl font-display font-bold text-sidebar-dark">
              {editingId ? 'Edit Campaign' : 'New Campaign'}
            </h3>
            <button type="button" onClick={() => setIsAdding(false)} className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-slate-100 text-slate-400 transition-colors">
              <X className="w-6 h-6" />
            </button>
          </div>
          <div className="space-y-2">
            <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest ml-1">Campaign Name</label>
            <input 
              required 
              type="text" 
              value={newCampaign.name || ''} 
              onChange={e => setNewCampaign({...newCampaign, name: e.target.value})} 
              className="w-full p-3.5 bg-slate-50 border border-slate-200 rounded-2xl text-sidebar-dark focus:outline-none focus:ring-2 focus:ring-brand-gold/20 focus:border-brand-gold transition-all"
            />
          </div>
          <div className="space-y-2">
            <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest ml-1">Platform</label>
            <select 
              value={newCampaign.platform} 
              onChange={e => setNewCampaign({...newCampaign, platform: e.target.value})} 
              className="w-full p-3.5 bg-slate-50 border border-slate-200 rounded-2xl text-sidebar-dark focus:outline-none focus:ring-2 focus:ring-brand-gold/20 focus:border-brand-gold transition-all appearance-none"
            >
              <option value="Facebook">Facebook</option>
              <option value="Google">Google</option>
              <option value="TikTok">TikTok</option>
              <option value="Other">Other</option>
            </select>
          </div>
          <div className="space-y-2">
            <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest ml-1">Budget (DZD)</label>
            <input 
              type="number" 
              required 
              min="0" 
              value={newCampaign.budget ?? ''} 
              onChange={e => setNewCampaign({...newCampaign, budget: Number(e.target.value)})} 
              className="w-full p-3.5 bg-slate-50 border border-slate-200 rounded-2xl text-sidebar-dark focus:outline-none focus:ring-2 focus:ring-brand-gold/20 focus:border-brand-gold transition-all font-bold"
            />
          </div>
          <div className="space-y-2">
            <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest ml-1">Leads Generated</label>
            <input 
              type="number" 
              min="0" 
              value={newCampaign.leads_generated ?? ''} 
              onChange={e => setNewCampaign({...newCampaign, leads_generated: Number(e.target.value)})} 
              className="w-full p-3.5 bg-slate-50 border border-slate-200 rounded-2xl text-sidebar-dark focus:outline-none focus:ring-2 focus:ring-brand-gold/20 focus:border-brand-gold transition-all font-bold"
            />
          </div>
          <div className="space-y-2">
            <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest ml-1">Appointments Set</label>
            <input 
              type="number" 
              min="0" 
              value={newCampaign.appointments_set ?? ''} 
              onChange={e => setNewCampaign({...newCampaign, appointments_set: Number(e.target.value)})} 
              className="w-full p-3.5 bg-slate-50 border border-slate-200 rounded-2xl text-sidebar-dark focus:outline-none focus:ring-2 focus:ring-brand-gold/20 focus:border-brand-gold transition-all font-bold"
            />
          </div>
          
          <div className="md:col-span-2 lg:col-span-3 flex justify-end space-x-4 mt-6">
            <button type="button" onClick={() => setIsAdding(false)} className="px-8 py-3 text-slate-400 hover:text-sidebar-dark font-bold text-sm transition-colors uppercase tracking-widest">Cancel</button>
            <button 
              type="submit" 
              disabled={saveMutation.isPending}
              className="px-10 py-3 bg-sidebar-dark text-white rounded-2xl hover:bg-slate-800 font-bold disabled:opacity-50 text-sm tracking-wide transition-all shadow-lg shadow-slate-200"
            >
              {saveMutation.isPending ? 'SAVING...' : 'SAVE CAMPAIGN'}
            </button>
          </div>
        </form>
      )}

      <div className="bg-white rounded-[2.5rem] shadow-sm border border-slate-200 overflow-hidden">
        {/* Desktop View */}
        <div className="hidden md:block overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50/50 text-[10px] text-slate-400 uppercase tracking-[0.2em] font-bold">
                <th className="px-8 py-5">Campaign</th>
                <th className="px-8 py-5">Platform</th>
                <th className="px-8 py-5 text-right">Budget</th>
                <th className="px-8 py-5 text-center">Leads</th>
                <th className="px-8 py-5 text-center">CPL</th>
                <th className="px-8 py-5 text-center">Deals</th>
                <th className="px-8 py-5 text-right">Revenue</th>
                <th className="px-8 py-5 text-right">ROI</th>
                <th className="px-8 py-5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {campaigns?.map((campaign: MarketingCampaign) => {
                const dealsClosed = 0; // Not supported in current schema
                const revenueGenerated = 0; // Not supported in current schema
                const cpl = campaign.leads_generated > 0 ? campaign.budget / campaign.leads_generated : 0;
                const roi = campaign.budget > 0 ? ((revenueGenerated - campaign.budget) / campaign.budget) * 100 : 0;

                return (
                  <tr key={campaign.id} className="hover:bg-slate-50/50 transition-colors group">
                    <td className="px-8 py-6 font-bold text-sidebar-dark">{campaign.name}</td>
                    <td className="px-8 py-6 text-sm text-slate-500 font-medium">{campaign.platform}</td>
                    <td className="px-8 py-6 text-right font-bold text-rose-500">{formatCurrency(campaign.budget)}</td>
                    <td className="px-8 py-6 text-center font-bold text-sidebar-dark">{campaign.leads_generated}</td>
                    <td className="px-8 py-6 text-center font-bold text-slate-400">{formatCurrency(cpl)}</td>
                    <td className="px-8 py-6 text-center font-bold text-emerald-600">{dealsClosed}</td>
                    <td className="px-8 py-6 text-right font-bold text-emerald-600">{formatCurrency(revenueGenerated)}</td>
                    <td className="px-8 py-6 text-right">
                      <span className={`inline-flex items-center px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest ${roi >= 0 ? 'bg-emerald-50 text-emerald-600 border border-emerald-100' : 'bg-rose-50 text-rose-600 border border-rose-100'}`}>
                        {roi >= 0 ? '+' : ''}{roi.toFixed(1)}%
                      </span>
                    </td>
                    <td className="px-8 py-6 text-right">
                      <div className="flex items-center justify-end gap-2 opacity-0 group-hover:opacity-100 transition-all">
                        <button 
                          onClick={() => { 
                            setNewCampaign({
                              name: campaign.name,
                              platform: campaign.platform,
                              budget: campaign.budget,
                              leads_generated: campaign.leads_generated,
                              appointments_set: campaign.appointments_set
                            }); 
                            setEditingId(campaign.id); 
                            setIsAdding(true); 
                          }} 
                          className="w-10 h-10 flex items-center justify-center text-slate-400 hover:text-brand-gold hover:bg-brand-gold/5 rounded-xl transition-all"
                        >
                          <Edit className="w-4 h-4" />
                        </button>
                        <button 
                          onClick={() => {
                            if (window.confirm('Delete this campaign?')) {
                              deleteMutation.mutate(campaign.id);
                            }
                          }} 
                          className="w-10 h-10 flex items-center justify-center text-slate-400 hover:text-rose-500 hover:bg-rose-50 rounded-xl transition-all"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
              {campaigns?.length === 0 && (
                <tr>
                  <td colSpan={9} className="px-8 py-20 text-center">
                    <div className="flex flex-col items-center gap-4">
                      <div className="w-16 h-16 rounded-3xl bg-slate-50 flex items-center justify-center text-slate-200">
                        <Megaphone className="w-8 h-8" />
                      </div>
                      <p className="text-slate-400 font-medium">No marketing campaigns found.</p>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Mobile View */}
        <div className="md:hidden divide-y divide-slate-50">
          {campaigns?.map((campaign: MarketingCampaign) => {
            const dealsClosed = 0; // Not supported in current schema
            const revenueGenerated = 0; // Not supported in current schema
            const roi = campaign.budget > 0 ? ((revenueGenerated - campaign.budget) / campaign.budget) * 100 : 0;

            return (
              <div key={campaign.id} className="p-6 space-y-6">
                <div className="flex items-start justify-between">
                  <div className="space-y-1">
                    <p className="font-bold text-sidebar-dark text-lg">{campaign.name}</p>
                    <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">{campaign.platform}</p>
                  </div>
                  <span className={`inline-flex items-center px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest ${roi >= 0 ? 'bg-emerald-50 text-emerald-600' : 'bg-rose-50 text-rose-600'}`}>
                    {roi >= 0 ? '+' : ''}{roi.toFixed(1)}% ROI
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-6">
                  <div className="space-y-1">
                    <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Budget</p>
                    <p className="text-sm font-bold text-rose-500">{formatCurrency(campaign.budget)}</p>
                  </div>
                  <div className="space-y-1 text-right">
                    <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Revenue</p>
                    <p className="text-sm font-bold text-emerald-600">{formatCurrency(revenueGenerated)}</p>
                  </div>
                  <div className="space-y-1">
                    <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Leads</p>
                    <p className="text-sm font-bold text-sidebar-dark">{campaign.leads_generated}</p>
                  </div>
                  <div className="space-y-1 text-right">
                    <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Deals Closed</p>
                    <p className="text-sm font-bold text-sidebar-dark">{dealsClosed}</p>
                  </div>
                </div>

                <div className="flex gap-3 pt-2">
                  <button 
                    onClick={() => { 
                      setNewCampaign({
                        name: campaign.name,
                        platform: campaign.platform,
                        budget: campaign.budget,
                        leads_generated: campaign.leads_generated,
                        appointments_set: campaign.appointments_set
                      }); 
                      setEditingId(campaign.id); 
                      setIsAdding(true); 
                    }} 
                    className="flex-1 py-3.5 bg-slate-50 text-sidebar-dark rounded-2xl font-bold text-xs uppercase tracking-widest hover:bg-slate-100 transition-colors"
                  >
                    Edit
                  </button>
                  <button 
                    onClick={() => {
                      if (window.confirm('Delete this campaign?')) {
                        deleteMutation.mutate(campaign.id);
                      }
                    }} 
                    className="flex-1 py-3.5 bg-rose-50 text-rose-500 rounded-2xl font-bold text-xs uppercase tracking-widest hover:bg-rose-100 transition-colors"
                  >
                    Delete
                  </button>
                </div>
              </div>
            );
          })}
          {campaigns?.length === 0 && (
            <div className="p-12 text-center">
              <p className="text-slate-400 font-medium">No campaigns found.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

