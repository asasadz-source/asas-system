import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useDeals, useTransactions } from '../hooks/useSupabaseData';
import { formatCurrency } from '../utils';
import { 
  Plus, 
  Search, 
  X, 
  Trash2, 
  ArrowDownUp, 
  DollarSign, 
  Loader2, 
  Briefcase,
  ArrowRightLeft,
  Edit2,
  CheckCircle2,
  Clock,
  AlertCircle,
  TrendingUp,
  User,
  Building2,
  Receipt
} from 'lucide-react';
import { format, parseISO } from 'date-fns';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '../lib/supabase';
import toast from 'react-hot-toast';
import { useAuth } from '../context/AuthContext';
import { DealsForm } from './DealsForm';
import { DealWizardModal } from './DealWizardModal';

export function Sales() {
  const { profile } = useAuth();
  const queryClient = useQueryClient();
  const [isAdding, setIsAdding] = useState(false);
  const [isDealWizardOpen, setIsDealWizardOpen] = useState(false);
  const [editingDeal, setEditingDeal] = useState<any>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [sortValueDesc, setSortValueDesc] = useState<boolean>(true);
  
  const { data: deals, isLoading: dealsLoading } = useDeals();
  const { data: transactions } = useTransactions();

  const deleteDealMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from('deals')
        .delete()
        .eq('id', id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['deals'] });
      toast.success('Deal deleted');
    },
    onError: (error: any) => {
      toast.error(error.message || 'Failed to delete deal');
    }
  });

  const filteredSales = (deals || []).filter(s => {
    const buyer = s.buyer?.name || '';
    const location = s.property?.location || '';
    const agent = s.agent?.name || '';
    
    const matchesSearch = buyer.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          location.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          agent.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || s.status === statusFilter;
    
    return matchesSearch && matchesStatus;
  });

  filteredSales.sort((a, b) => {
    if (sortValueDesc) {
      return (b.total_amount || 0) - (a.total_amount || 0);
    } else {
      return (a.total_amount || 0) - (b.total_amount || 0);
    }
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'finalized': return 'bg-emerald-50 text-emerald-600 border-emerald-100';
      case 'pending': return 'bg-amber-50 text-amber-600 border-amber-100';
      case 'cancelled': return 'bg-rose-50 text-rose-600 border-rose-100';
      default: return 'bg-slate-50 text-slate-500 border-slate-100';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'finalized': return <CheckCircle2 className="w-3.5 h-3.5" />;
      case 'pending': return <Clock className="w-3.5 h-3.5" />;
      case 'cancelled': return <AlertCircle className="w-3.5 h-3.5" />;
      default: return null;
    }
  };

  const calculateReceived = (dealId: string) => {
    if (!transactions) return 0;
    return transactions
      .filter(t => t.type === 'deposit' && (t as any).deal_id === dealId)
      .reduce((sum, t) => sum + t.amount, 0);
  };

  const totalExpected = filteredSales.reduce((sum, d) => sum + (d.total_amount || 0), 0);
  const totalReceived = filteredSales.reduce((sum, d) => sum + calculateReceived(d.id), 0);

  if (dealsLoading) {
    return (
      <div className="flex flex-col items-center justify-center p-20 space-y-4">
        <Loader2 className="w-10 h-10 animate-spin text-brand-gold" />
        <p className="text-slate-400 font-medium animate-pulse">Loading sales data...</p>
      </div>
    );
  }

  return (
    <div className="space-y-8 pb-10">
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-6">
        <div>
          <h2 className="text-3xl lg:text-4xl font-display font-bold text-sidebar-dark tracking-tight">Sales & Deals</h2>
          <p className="text-slate-500 font-medium mt-1">Track property sales, commissions, and payment status</p>
        </div>
        <div className="flex flex-col sm:flex-row gap-4 w-full lg:w-auto">
          <button
            onClick={() => setIsDealWizardOpen(true)}
            className="flex items-center gap-2 px-6 py-3.5 bg-white text-brand-navy-900 rounded-2xl hover:bg-slate-50 transition-all border border-slate-200 shadow-sm justify-center font-bold text-sm tracking-wide"
          >
            <ArrowRightLeft className="w-4 h-4 text-brand-gold-500" />
            NEW DEAL WIZARD
          </button>
          <button
            onClick={() => {
              setEditingDeal(null);
              setIsAdding(true);
            }}
            className="flex items-center gap-2 px-8 py-3.5 bg-brand-gold text-sidebar-dark rounded-2xl hover:bg-brand-gold/90 transition-all font-bold shadow-xl shadow-brand-gold/20 justify-center text-sm tracking-wide"
          >
            <Plus className="w-5 h-5" />
            ADD SALE
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm hover:border-brand-gold/20 transition-all group">
          <p className="text-slate-400 text-[10px] uppercase tracking-[0.2em] font-bold mb-2">Total Sales Value</p>
          <p className="text-3xl font-bold text-sidebar-dark tracking-tight">
            {formatCurrency(filteredSales.reduce((sum, d) => sum + (d.total_amount || 0), 0))}
          </p>
        </div>
        <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm hover:border-emerald-500/20 transition-all group">
          <p className="text-slate-400 text-[10px] uppercase tracking-[0.2em] font-bold mb-2">Expected Commission</p>
          <p className="text-3xl font-bold text-emerald-600 tracking-tight">
            {formatCurrency(totalExpected)}
          </p>
        </div>
        <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm hover:border-brand-gold/20 transition-all group">
          <p className="text-slate-400 text-[10px] uppercase tracking-[0.2em] font-bold mb-2">Commission Collected</p>
          <p className="text-3xl font-bold text-brand-gold tracking-tight">
            {formatCurrency(totalReceived)}
          </p>
        </div>
      </div>

      <div className="bg-white border border-slate-200 rounded-3xl shadow-sm overflow-hidden">
        <div className="p-6 border-b border-slate-100 flex flex-col lg:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 w-5 h-5" />
            <input
              type="text"
              placeholder="Search sales, clients, agents..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-12 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-2xl text-sidebar-dark placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-brand-gold/20 focus:border-brand-gold transition-all"
            />
          </div>
          <div className="flex gap-3">
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="bg-slate-50 border border-slate-200 rounded-2xl px-5 py-3 text-sidebar-dark font-bold text-sm focus:outline-none focus:ring-2 focus:ring-brand-gold/20 transition-all appearance-none min-w-[160px]"
            >
              <option value="all">All Statuses</option>
              <option value="Reserved">Reserved</option>
              <option value="Pending Balance">Pending Balance</option>
              <option value="Fully Paid">Fully Paid</option>
              <option value="Cancelled">Cancelled</option>
            </select>
            <button
              onClick={() => setSortValueDesc(!sortValueDesc)}
              className="flex items-center justify-center gap-3 px-6 py-3 bg-slate-50 border border-slate-200 rounded-2xl text-slate-500 hover:text-brand-gold hover:border-brand-gold/30 transition-all"
            >
              <ArrowDownUp className="w-4 h-4" />
              <span className="text-sm font-bold uppercase tracking-widest hidden sm:inline">
                {sortValueDesc ? 'Highest' : 'Lowest'}
              </span>
            </button>
          </div>
        </div>

        {/* Desktop View */}
        <div className="hidden md:block overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50/50 text-slate-400 text-[10px] uppercase tracking-[0.2em] font-bold">
                <th className="px-8 py-5">Property & Project</th>
                <th className="px-8 py-5">Client</th>
                <th className="px-8 py-5">Status</th>
                <th className="px-8 py-5 text-right">Price</th>
                <th className="px-8 py-5 text-right">Commission</th>
                <th className="px-8 py-5 text-right">Collected</th>
                <th className="px-8 py-5 text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {filteredSales.map((sale) => {
                const received = calculateReceived(sale.id);
                return (
                <tr key={sale.id} className="hover:bg-slate-50/50 transition-colors group">
                  <td className="px-8 py-6">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 rounded-2xl bg-slate-50 border border-slate-100 flex items-center justify-center text-brand-gold group-hover:bg-brand-gold group-hover:text-white transition-all duration-300">
                        <Building2 className="w-6 h-6" />
                      </div>
                      <div>
                        <p className="font-bold text-sidebar-dark text-sm">{sale.property?.location}</p>
                        <p className="text-xs text-slate-400 font-medium mt-0.5">{sale.property?.type}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-8 py-6">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center text-slate-400">
                        <User className="w-5 h-5" />
                      </div>
                      <div>
                        <p className="text-sidebar-dark text-sm font-bold">{sale.buyer?.name}</p>
                        <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-0.5">Agent: {sale.agent?.name?.split(' ')[0]}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-8 py-6">
                    <span className={`inline-flex items-center gap-2 px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest border ${getStatusColor(sale.status)}`}>
                      {getStatusIcon(sale.status)}
                      {sale.status}
                    </span>
                  </td>
                  <td className="px-8 py-6 text-right font-bold text-sidebar-dark">
                    {formatCurrency(sale.property?.price || 0)}
                  </td>
                  <td className="px-8 py-6 text-right font-bold text-emerald-600">
                    {formatCurrency(sale.total_amount || 0)}
                  </td>
                  <td className="px-8 py-6 text-right">
                    <div className="flex flex-col items-end">
                      <span className="font-bold text-brand-gold">{formatCurrency(received)}</span>
                      <div className="w-24 h-1.5 bg-slate-100 rounded-full mt-2 overflow-hidden">
                        <motion.div 
                          initial={{ width: 0 }}
                          animate={{ width: `${Math.min(100, (received / (sale.total_amount || 1)) * 100)}%` }}
                          transition={{ duration: 1, ease: "easeOut" }}
                          className="h-full bg-brand-gold rounded-full"
                        />
                      </div>
                    </div>
                  </td>
                  <td className="px-8 py-6">
                    <div className="flex items-center justify-center gap-2 opacity-0 group-hover:opacity-100 transition-all">
                      <button
                        onClick={() => {
                          setEditingDeal(sale);
                          setIsAdding(true);
                        }}
                        className="w-10 h-10 flex items-center justify-center text-slate-400 hover:text-brand-gold hover:bg-brand-gold/5 rounded-xl transition-all"
                        title="Edit Deal"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                      {profile?.role === 'admin' && (
                        <button
                          onClick={() => {
                            if (window.confirm('Are you sure you want to delete this deal? This will also delete all associated transactions.')) {
                              deleteDealMutation.mutate(sale.id);
                            }
                          }}
                          className="w-10 h-10 flex items-center justify-center text-slate-400 hover:text-rose-500 hover:bg-rose-50 rounded-xl transition-all"
                          title="Delete Deal"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
                );
              })}
              {filteredSales.length === 0 && (
                <tr>
                  <td colSpan={7} className="px-8 py-20 text-center">
                    <div className="flex flex-col items-center gap-4">
                      <div className="w-16 h-16 rounded-3xl bg-slate-50 flex items-center justify-center text-slate-200">
                        <Receipt className="w-8 h-8" />
                      </div>
                      <p className="text-slate-400 font-medium">No deals found matching your criteria.</p>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Mobile Card View */}
        <div className="md:hidden divide-y divide-slate-50">
          {filteredSales.map((sale) => {
            const received = calculateReceived(sale.id);
            return (
            <div key={sale.id} className="p-6 space-y-6">
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-2xl bg-slate-50 flex items-center justify-center text-brand-gold">
                    <Building2 className="w-6 h-6" />
                  </div>
                  <div>
                    <p className="font-bold text-sidebar-dark text-base">{sale.property?.location}</p>
                    <p className="text-xs text-slate-400 font-medium">{sale.property?.type}</p>
                  </div>
                </div>
                <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[9px] font-bold uppercase tracking-widest border ${getStatusColor(sale.status)}`}>
                  {sale.status}
                </span>
              </div>

              <div className="grid grid-cols-2 gap-4 pt-2">
                <div className="flex flex-col">
                  <span className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Client</span>
                  <span className="text-sm font-bold text-sidebar-dark truncate">{sale.buyer?.name}</span>
                </div>
                <div className="flex flex-col text-right">
                  <span className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Price</span>
                  <span className="text-sm font-bold text-sidebar-dark">{formatCurrency(sale.property?.price || 0)}</span>
                </div>
              </div>

              <div className="space-y-3 pt-2">
                <div className="flex justify-between items-end">
                  <span className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Commission Collected</span>
                  <div className="text-right">
                    <span className="text-sm font-bold text-brand-gold">{formatCurrency(received)}</span>
                    <span className="text-[10px] text-slate-400 font-bold ml-1">/ {formatCurrency(sale.total_amount || 0)}</span>
                  </div>
                </div>
                <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                  <motion.div 
                    initial={{ width: 0 }}
                    animate={{ width: `${Math.min(100, (received / (sale.total_amount || 1)) * 100)}%` }}
                    transition={{ duration: 1, ease: "easeOut" }}
                    className="h-full bg-brand-gold rounded-full"
                  />
                </div>
              </div>

              <div className="flex gap-3 pt-2">
                <button
                  onClick={() => {
                    setEditingDeal(sale);
                    setIsAdding(true);
                  }}
                  className="flex-1 py-3.5 bg-slate-50 text-sidebar-dark rounded-2xl font-bold text-xs uppercase tracking-widest hover:bg-slate-100 transition-colors"
                >
                  Edit Deal
                </button>
                {profile?.role === 'admin' && (
                  <button
                    onClick={() => {
                      if (window.confirm('Are you sure you want to delete this deal?')) {
                        deleteDealMutation.mutate(sale.id);
                      }
                    }}
                    className="flex-1 py-3.5 bg-rose-50 text-rose-500 rounded-2xl font-bold text-xs uppercase tracking-widest hover:bg-rose-100 transition-colors"
                  >
                    Delete
                  </button>
                )}
              </div>
            </div>
            );
          })}
          {filteredSales.length === 0 && (
            <div className="p-12 text-center">
              <p className="text-slate-400 font-medium">No deals found.</p>
            </div>
          )}
        </div>
      </div>

      {isAdding && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/40 backdrop-blur-sm">
          <motion.div 
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            className="bg-white rounded-[2.5rem] p-8 shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto"
          >
            <div className="flex justify-between items-center mb-8 border-b border-slate-100 pb-6">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-brand-gold/10 flex items-center justify-center text-brand-gold">
                  <Briefcase className="w-5 h-5" />
                </div>
                <h3 className="text-2xl font-display font-bold text-sidebar-dark">
                  {editingDeal ? 'Edit Sale Record' : 'New Sale Record'}
                </h3>
              </div>
              <button onClick={() => setIsAdding(false)} className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-slate-100 text-slate-400 transition-colors">
                <X className="w-6 h-6" />
              </button>
            </div>
            <DealsForm 
              initialData={editingDeal}
              onClose={() => setIsAdding(false)}
            />
          </motion.div>
        </div>
      )}

      {isDealWizardOpen && (
        <DealWizardModal 
          onClose={() => setIsDealWizardOpen(false)} 
        />
      )}
    </div>
  );
}


