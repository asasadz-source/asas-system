import React, { useState } from 'react';
import { useTransactions, useDeals } from '../hooks/useSupabaseData';
import { formatCurrency } from '../utils';
import { Plus, Search, X, Trash2, ArrowDownUp, Filter, Loader2, TrendingUp } from 'lucide-react';
import { format, parseISO } from 'date-fns';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '../lib/supabase';
import toast from 'react-hot-toast';
import { useAuth } from '../context/AuthContext';

export function Revenues() {
  const { profile } = useAuth();
  const queryClient = useQueryClient();
  const [isAdding, setIsAdding] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterMonth, setFilterMonth] = useState<string>('all');
  const [sortValueDesc, setSortValueDesc] = useState(true);
  
  const { data: transactions, isLoading: transLoading } = useTransactions();
  const { data: deals } = useDeals();

  const revenues = transactions?.filter(t => t.amount > 0 && t.type !== 'PARTNER_DRAW') || [];

  const addMutation = useMutation({
    mutationFn: async (newRevenue: any) => {
      const { error } = await supabase
        .from('payments')
        .insert({
          deal_id: newRevenue.deal_id,
          type: newRevenue.type,
          amount: Math.abs(newRevenue.amount), // Revenues are positive
          status: 'completed',
          paid_at: new Date().toISOString()
        });
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['transactions'] });
      queryClient.invalidateQueries({ queryKey: ['partners_equity'] });
      toast.success('Revenue recorded successfully');
      setIsAdding(false);
    },
    onError: (error: any) => {
      toast.error(error.message || 'Failed to record revenue');
    }
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from('payments')
        .delete()
        .eq('id', id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['transactions'] });
      queryClient.invalidateQueries({ queryKey: ['partners_equity'] });
      toast.success('Revenue record deleted');
    },
    onError: (error: any) => {
      toast.error(error.message || 'Failed to delete revenue record');
    }
  });

  const handleAddRevenue = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const data = {
      type: formData.get('type'),
      deal_id: formData.get('deal_id') || null,
      amount: Number(formData.get('amount')),
      description: formData.get('description'),
      created_at: new Date(formData.get('date') as string).toISOString(),
    };
    addMutation.mutate(data);
  };

  const availableMonths = Array.from(new Set(revenues.map(r => r.created_at.substring(0, 7)))).sort().reverse();

  let filteredRevenues = revenues.filter(r => 
    (r.type.toLowerCase().includes(searchTerm.toLowerCase())) &&
    (filterMonth === 'all' || r.created_at.startsWith(filterMonth))
  );

  filteredRevenues.sort((a, b) => {
    if (sortValueDesc) {
      return b.amount - a.amount;
    } else {
      return a.amount - b.amount;
    }
  });

  if (transLoading) {
    return (
      <div className="flex flex-col items-center justify-center p-20 space-y-4">
        <Loader2 className="w-10 h-10 animate-spin text-brand-gold" />
        <p className="text-slate-400 font-medium animate-pulse">Loading revenues...</p>
      </div>
    );
  }

  return (
    <div className="space-y-8 pb-10">
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-6">
        <div>
          <h2 className="text-3xl lg:text-4xl font-display font-bold text-sidebar-dark tracking-tight">Revenue Records</h2>
          <p className="text-slate-500 font-medium mt-1">Manage agency income and commission tranches</p>
        </div>
        
        {profile?.role === 'admin' && (
          <button
            onClick={() => setIsAdding(true)}
            className="flex items-center space-x-2 bg-brand-gold text-sidebar-dark px-8 py-3.5 rounded-2xl hover:bg-brand-gold/90 font-bold transition-all shadow-xl shadow-brand-gold/20 text-sm tracking-wide w-full lg:w-auto justify-center"
          >
            <Plus className="w-5 h-5" />
            <span>ADD REVENUE</span>
          </button>
        )}
      </div>

      <div className="flex flex-col md:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 w-5 h-5" />
          <input
            type="text"
            placeholder="Search revenues..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-12 pr-4 py-3.5 bg-white border border-slate-200 rounded-2xl text-sidebar-dark focus:outline-none focus:ring-2 focus:ring-brand-gold/20 focus:border-brand-gold transition-all shadow-sm"
          />
        </div>
        
        <div className="flex gap-3">
          <div className="relative min-w-[180px]">
            <Filter className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 w-4 h-4" />
            <select
              value={filterMonth}
              onChange={(e) => setFilterMonth(e.target.value)}
              className="w-full pl-10 pr-10 py-3.5 bg-white border border-slate-200 rounded-2xl text-sidebar-dark focus:outline-none focus:ring-2 focus:ring-brand-gold/20 focus:border-brand-gold transition-all shadow-sm appearance-none font-bold text-sm"
            >
              <option value="all">All Months</option>
              {availableMonths.map(month => (
                <option key={month} value={month}>
                  {format(parseISO(`${month}-01`), 'MMMM yyyy')}
                </option>
              ))}
            </select>
          </div>
          
          <button
            onClick={() => setSortValueDesc(!sortValueDesc)}
            className="w-12 h-12 flex items-center justify-center bg-white border border-slate-200 rounded-2xl text-slate-400 hover:text-sidebar-dark transition-all shadow-sm"
            title={sortValueDesc ? "Sort Low to High" : "Sort High to Low"}
          >
            <ArrowDownUp className={`w-5 h-5 transition-transform ${sortValueDesc ? '' : 'rotate-180'}`} />
          </button>
        </div>
      </div>

      {isAdding && (
        <div className="bg-white border border-slate-200 p-8 rounded-[2.5rem] shadow-sm">
          <div className="flex justify-between items-center mb-8 border-b border-slate-100 pb-6">
            <h3 className="text-2xl font-display font-bold text-sidebar-dark flex items-center gap-3">
              <TrendingUp className="w-6 h-6 text-emerald-500" />
              New Revenue Record
            </h3>
            <button onClick={() => setIsAdding(false)} className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-slate-100 text-slate-400 transition-colors">
              <X className="w-6 h-6" />
            </button>
          </div>
          <form onSubmit={handleAddRevenue} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <div className="space-y-2">
              <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest ml-1">Date</label>
              <input
                type="date"
                name="date"
                required
                defaultValue={format(new Date(), 'yyyy-MM-dd')}
                className="w-full p-3.5 bg-slate-50 border border-slate-200 rounded-2xl text-sidebar-dark focus:outline-none focus:ring-2 focus:ring-brand-gold/20 focus:border-brand-gold transition-all"
              />
            </div>
            <div className="space-y-2">
              <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest ml-1">Type</label>
              <select
                name="type"
                required
                className="w-full p-3.5 bg-slate-50 border border-slate-200 rounded-2xl text-sidebar-dark focus:outline-none focus:ring-2 focus:ring-brand-gold/20 focus:border-brand-gold transition-all appearance-none"
              >
                <option value="COMMISSION_TRANCHE">Commission Tranche</option>
                <option value="RESERVATION">Reservation</option>
                <option value="NEW_DEAL">New Deal Initial</option>
              </select>
            </div>
            <div className="space-y-2">
              <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest ml-1">Amount (DZD)</label>
              <input
                type="number"
                name="amount"
                required
                min="0"
                step="0.01"
                className="w-full p-3.5 bg-slate-50 border border-slate-200 rounded-2xl text-sidebar-dark focus:outline-none focus:ring-2 focus:ring-brand-gold/20 focus:border-brand-gold transition-all font-bold"
                placeholder="0.00"
              />
            </div>
            <div className="space-y-2">
              <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest ml-1">Related Deal (Optional)</label>
              <select
                name="deal_id"
                className="w-full p-3.5 bg-slate-50 border border-slate-200 rounded-2xl text-sidebar-dark focus:outline-none focus:ring-2 focus:ring-brand-gold/20 focus:border-brand-gold transition-all appearance-none"
              >
                <option value="">None</option>
                {deals?.map(d => (
                  <option key={d.id} value={d.id}>
                    {d.property?.location} - {d.buyer?.name}
                  </option>
                ))}
              </select>
            </div>
            <div className="lg:col-span-2 space-y-2">
              <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest ml-1">Description</label>
              <input
                type="text"
                name="description"
                required
                className="w-full p-3.5 bg-slate-50 border border-slate-200 rounded-2xl text-sidebar-dark focus:outline-none focus:ring-2 focus:ring-brand-gold/20 focus:border-brand-gold transition-all"
                placeholder="Brief description of the income..."
              />
            </div>
            <div className="lg:col-span-3 flex justify-end gap-4 mt-6 pt-8 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setIsAdding(false)}
                className="px-8 py-3 text-slate-400 hover:text-sidebar-dark font-bold text-sm transition-colors uppercase tracking-widest"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={addMutation.isPending}
                className="px-10 py-3 bg-sidebar-dark text-white rounded-2xl hover:bg-slate-800 font-bold disabled:opacity-50 text-sm tracking-wide transition-all shadow-lg shadow-slate-200"
              >
                {addMutation.isPending ? 'SAVING...' : 'SAVE REVENUE'}
              </button>
            </div>
          </form>
        </div>
      )}

      <div className="bg-white rounded-[2.5rem] shadow-sm border border-slate-200 overflow-hidden">
        {/* Desktop View */}
        <div className="hidden md:block overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50/50 text-[10px] text-slate-400 uppercase tracking-[0.2em] font-bold">
                <th className="px-8 py-5">Date</th>
                <th className="px-8 py-5">Type</th>
                <th className="px-8 py-5">Description</th>
                <th className="px-8 py-5">Related Deal</th>
                <th className="px-8 py-5 text-right">Amount</th>
                {profile?.role === 'admin' && <th className="px-8 py-5 text-right">Actions</th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {filteredRevenues.map((revenue) => (
                <tr key={revenue.id} className="hover:bg-slate-50/50 transition-colors group">
                  <td className="px-8 py-6 text-slate-400 whitespace-nowrap text-sm font-medium">
                    {format(parseISO(revenue.created_at), 'dd MMM yyyy')}
                  </td>
                  <td className="px-8 py-6">
                    <span className="inline-flex items-center px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest bg-slate-100 text-slate-500 border border-slate-200">
                      {revenue.type.replace('_', ' ')}
                    </span>
                  </td>
                  <td className="px-8 py-6 text-sidebar-dark font-bold">
                    {revenue.type}
                  </td>
                  <td className="px-8 py-6 text-slate-500 font-medium">
                    {(revenue as any).deal_id || '-'}
                  </td>
                  <td className="px-8 py-6 text-right font-bold text-emerald-600">
                    +{formatCurrency(revenue.amount)}
                  </td>
                  {profile?.role === 'admin' && (
                    <td className="px-8 py-6 text-right">
                      <button 
                        onClick={() => {
                          if (window.confirm('Delete this revenue record?')) {
                            deleteMutation.mutate(revenue.id);
                          }
                        }}
                        className="w-10 h-10 flex items-center justify-center text-slate-400 hover:text-rose-500 hover:bg-rose-50 rounded-xl transition-all opacity-0 group-hover:opacity-100"
                        title="Delete Revenue"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  )}
                </tr>
              ))}
              {filteredRevenues.length === 0 && (
                <tr>
                  <td colSpan={profile?.role === 'admin' ? 6 : 5} className="px-8 py-20 text-center">
                    <div className="flex flex-col items-center gap-4">
                      <div className="w-16 h-16 rounded-3xl bg-slate-50 flex items-center justify-center text-slate-200">
                        <TrendingUp className="w-8 h-8" />
                      </div>
                      <p className="text-slate-400 font-medium">No revenues found matching your criteria.</p>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Mobile View */}
        <div className="md:hidden divide-y divide-slate-50">
          {filteredRevenues.map((revenue) => (
            <div key={revenue.id} className="p-6 space-y-4">
              <div className="flex items-start justify-between">
                <div className="space-y-1">
                  <p className="font-bold text-sidebar-dark">{revenue.type}</p>
                  <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">{format(parseISO(revenue.created_at), 'dd MMM yyyy')}</p>
                </div>
                <p className="text-lg font-bold text-emerald-600">+{formatCurrency(revenue.amount)}</p>
              </div>
              
              <div className="flex items-center justify-between pt-2">
                <span className="inline-flex items-center px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest bg-slate-100 text-slate-500">
                  {revenue.type.replace('_', ' ')}
                </span>
                {profile?.role === 'admin' && (
                  <button 
                    onClick={() => {
                      if (window.confirm('Delete this revenue record?')) {
                        deleteMutation.mutate(revenue.id);
                      }
                    }}
                    className="p-2 text-slate-400 hover:text-rose-500 transition-colors"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                )}
              </div>
            </div>
          ))}
          {filteredRevenues.length === 0 && (
            <div className="p-12 text-center">
              <p className="text-slate-400 font-medium">No revenues found.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

