import React, { useState } from 'react';
import { useForm, useWatch } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';
import { useProjects, useClients, useAgents } from '../hooks/useSupabaseData';
import toast from 'react-hot-toast';
import { X, ArrowRightLeft, User, Briefcase, Percent, DollarSign, Building2, Loader2 } from 'lucide-react';

const dealWizardSchema = z.object({
  property_id: z.string().min(1, 'Property is required'),
  client_id: z.string().min(1, 'Client is required'),
  agent_id: z.string().min(1, 'Agent is required'),
  marketing_campaign_id: z.string().optional(),
  
  total_amount: z.number().min(0, 'Total amount must be positive'),
  initial_deposit: z.number().min(0, 'Initial deposit must be positive'),
  
  commission_rate: z.number().min(0).max(100),
  agent_split_rate: z.number().min(0).max(100),
  promoter_split_rate: z.number().min(0).max(100),
}).superRefine((data, ctx) => {
  if (data.agent_split_rate + data.promoter_split_rate > 100) {
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      message: "Total split cannot exceed 100%",
      path: ["agent_split_rate"]
    });
  }
});

type DealWizardFormValues = z.infer<typeof dealWizardSchema>;

interface DealWizardModalProps {
  onClose: () => void;
  deals?: any[];
}

export function DealWizardModal({ onClose }: DealWizardModalProps) {
  const { profile } = useAuth();
  const queryClient = useQueryClient();

  const { data: projects } = useProjects();
  const { data: clients } = useClients();
  const { data: agents } = useAgents();

  const [step, setStep] = useState(1);

  const {
    register,
    handleSubmit,
    control,
    formState: { errors },
  } = useForm<DealWizardFormValues>({
    resolver: zodResolver(dealWizardSchema),
    defaultValues: {
      agent_id: profile?.id || '',
      commission_rate: 5,
      agent_split_rate: 50,
      promoter_split_rate: 0,
      initial_deposit: 0,
    },
  });

  const agentSplit = useWatch({ control, name: 'agent_split_rate' }) || 0;
  const promoterSplit = useWatch({ control, name: 'promoter_split_rate' }) || 0;
  const agencySplit = Math.max(0, 100 - agentSplit - promoterSplit);
  const isSplitValid = agentSplit + promoterSplit <= 100;

  const mutation = useMutation({
    mutationFn: async (data: DealWizardFormValues) => {
      if (!profile) throw new Error('Not authenticated');

      const { data: result, error } = await supabase.rpc('create_deal_atomic', {
        p_property_id: data.property_id,
        p_buyer_id: data.client_id,
        p_agent_id: data.agent_id,
        p_marketing_campaign_id: data.marketing_campaign_id || null,
        p_total_amount: data.total_amount,
        p_commission_rate: data.commission_rate,
        p_agent_split_rate: data.agent_split_rate,
        p_promoter_split_rate: data.promoter_split_rate,
        p_initial_deposit: data.initial_deposit
      });

      if (error) {
        throw new Error(error.message);
      }
      return result;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['deals'] });
      queryClient.invalidateQueries({ queryKey: ['transactions'] });
      queryClient.invalidateQueries({ queryKey: ['partners_equity'] });
      queryClient.invalidateQueries({ queryKey: ['properties'] });
      toast.success('Deal Executed Successfully');
      onClose();
    },
    onError: (error: any) => {
      toast.error(error.message || 'Failed to execute deal');
    },
  });

  const onSubmit = (data: DealWizardFormValues) => {
    mutation.mutate(data);
  };

  const availableProjects = projects?.filter(p => p.status === 'available') || [];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-brand-navy-900/80 backdrop-blur-sm" dir="auto">
      <div className="bg-white rounded-3xl p-8 shadow-2xl w-full max-w-3xl max-h-[90vh] overflow-y-auto">
        <div className="flex justify-between items-center mb-8 border-b border-slate-100 pb-6">
          <div>
            <h3 className="text-2xl font-display font-bold text-brand-navy-900 flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-brand-gold-500/10 flex items-center justify-center">
                <ArrowRightLeft className="w-5 h-5 text-brand-gold-500" />
              </div>
              Atomic Deal Wizard
            </h3>
            <p className="text-sm text-slate-500 font-medium mt-2">Enterprise-grade deal execution with ledger accrual.</p>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-brand-navy-900 transition-colors p-2 rounded-xl hover:bg-slate-50"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-8">
          
          {/* STEP 1: Asset & Buyer */}
          <div className={`space-y-6 ${step !== 1 ? 'hidden' : ''}`}>
            <h4 className="text-sm font-bold text-brand-gold-500 uppercase tracking-widest flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-brand-gold-500/10 flex items-center justify-center">1</span>
              The Asset & The Buyer
            </h4>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="md:col-span-2">
                <label className="block text-sm font-bold text-brand-navy-900 mb-2 flex items-center gap-2">
                  <Building2 className="w-4 h-4 text-slate-400" />
                  Property (Available Only)
                </label>
                <select
                  {...register('property_id')}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-brand-navy-900 focus:outline-none focus:ring-2 focus:ring-brand-gold-500/50 focus:border-brand-gold-500 transition-colors font-medium"
                >
                  <option value="">Select Property</option>
                  {availableProjects.map(p => (
                    <option key={p.id} value={p.id}>{p.location} - {p.type}</option>
                  ))}
                </select>
                {errors.property_id && <p className="mt-1 text-xs font-bold text-semantic-error-600">{errors.property_id.message}</p>}
              </div>

              <div>
                <label className="block text-sm font-bold text-brand-navy-900 mb-2 flex items-center gap-2">
                  <User className="w-4 h-4 text-slate-400" />
                  Client (Buyer)
                </label>
                <select
                  {...register('client_id')}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-brand-navy-900 focus:outline-none focus:ring-2 focus:ring-brand-gold-500/50 focus:border-brand-gold-500 transition-colors font-medium"
                >
                  <option value="">Select Client</option>
                  {clients?.map(c => (
                    <option key={c.id} value={c.id}>{c.name}</option>
                  ))}
                </select>
                {errors.client_id && <p className="mt-1 text-xs font-bold text-semantic-error-600">{errors.client_id.message}</p>}
              </div>

              <div>
                <label className="block text-sm font-bold text-brand-navy-900 mb-2 flex items-center gap-2">
                  <Briefcase className="w-4 h-4 text-slate-400" />
                  Assigned Agent
                </label>
                <select
                  {...register('agent_id')}
                  disabled={profile?.role !== 'admin'}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-brand-navy-900 focus:outline-none focus:ring-2 focus:ring-brand-gold-500/50 focus:border-brand-gold-500 transition-colors font-medium disabled:opacity-50"
                >
                  <option value="">Select Agent</option>
                  {agents?.map(a => (
                    <option key={a.id} value={a.id}>{a.name}</option>
                  ))}
                </select>
                {errors.agent_id && <p className="mt-1 text-xs font-bold text-semantic-error-600">{errors.agent_id.message}</p>}
              </div>
            </div>

            <div className="flex justify-end pt-4">
              <button 
                type="button" 
                onClick={() => setStep(2)}
                className="px-8 py-3 bg-brand-navy-900 text-white rounded-xl font-bold text-sm tracking-wide hover:bg-brand-navy-800 transition-colors"
              >
                Next: Financials
              </button>
            </div>
          </div>

          {/* STEP 2: Financials */}
          <div className={`space-y-6 ${step !== 2 ? 'hidden' : ''}`}>
            <h4 className="text-sm font-bold text-brand-gold-500 uppercase tracking-widest flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-brand-gold-500/10 flex items-center justify-center">2</span>
              The Financials
            </h4>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-bold text-brand-navy-900 mb-2 flex items-center gap-2">
                  <DollarSign className="w-4 h-4 text-slate-400" />
                  Total Deal Amount (DZD)
                </label>
                <input
                  type="number"
                  step="0.01"
                  {...register('total_amount', { valueAsNumber: true })}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-brand-navy-900 focus:outline-none focus:ring-2 focus:ring-brand-gold-500/50 focus:border-brand-gold-500 transition-colors font-mono font-bold text-lg"
                />
                {errors.total_amount && <p className="mt-1 text-xs font-bold text-semantic-error-600">{errors.total_amount.message}</p>}
              </div>

              <div>
                <label className="block text-sm font-bold text-brand-navy-900 mb-2 flex items-center gap-2">
                  <DollarSign className="w-4 h-4 text-slate-400" />
                  Initial Deposit (DZD)
                </label>
                <input
                  type="number"
                  step="0.01"
                  {...register('initial_deposit', { valueAsNumber: true })}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-brand-navy-900 focus:outline-none focus:ring-2 focus:ring-brand-gold-500/50 focus:border-brand-gold-500 transition-colors font-mono font-bold text-lg"
                />
                {errors.initial_deposit && <p className="mt-1 text-xs font-bold text-semantic-error-600">{errors.initial_deposit.message}</p>}
              </div>
            </div>

            <div className="flex justify-between pt-4">
              <button 
                type="button" 
                onClick={() => setStep(1)}
                className="px-8 py-3 bg-slate-100 text-slate-600 rounded-xl font-bold text-sm tracking-wide hover:bg-slate-200 transition-colors"
              >
                Back
              </button>
              <button 
                type="button" 
                onClick={() => setStep(3)}
                className="px-8 py-3 bg-brand-navy-900 text-white rounded-xl font-bold text-sm tracking-wide hover:bg-brand-navy-800 transition-colors"
              >
                Next: Commission Splits
              </button>
            </div>
          </div>

          {/* STEP 3: Splits */}
          <div className={`space-y-6 ${step !== 3 ? 'hidden' : ''}`}>
            <h4 className="text-sm font-bold text-brand-gold-500 uppercase tracking-widest flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-brand-gold-500/10 flex items-center justify-center">3</span>
              Commission Splits
            </h4>

            <div className="bg-slate-50 p-6 rounded-2xl border border-slate-200 space-y-6">
              <div>
                <label className="block text-sm font-bold text-brand-navy-900 mb-2 flex items-center gap-2">
                  <Percent className="w-4 h-4 text-slate-400" />
                  Base Commission Rate (%)
                </label>
                <input
                  type="number"
                  step="0.1"
                  {...register('commission_rate', { valueAsNumber: true })}
                  className="w-full bg-white border border-slate-200 rounded-xl px-4 py-3 text-brand-navy-900 focus:outline-none focus:ring-2 focus:ring-brand-gold-500/50 focus:border-brand-gold-500 transition-colors font-mono font-bold"
                />
              </div>

              <div className="pt-4 border-t border-slate-200">
                <h5 className="text-xs font-bold text-slate-500 uppercase tracking-widest mb-4">The 100% Split Rule</h5>
                
                <div className="grid grid-cols-2 gap-6 mb-6">
                  <div>
                    <label className="block text-xs font-bold text-brand-navy-900 mb-2">Agent Split (%)</label>
                    <input
                      type="number"
                      step="1"
                      {...register('agent_split_rate', { valueAsNumber: true })}
                      className={`w-full bg-white border rounded-xl px-4 py-3 text-brand-navy-900 font-mono font-bold focus:outline-none ${!isSplitValid ? 'border-semantic-error-600 ring-1 ring-semantic-error-600' : 'border-slate-200 focus:border-brand-gold-500'}`}
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-brand-navy-900 mb-2">Promoter Split (%)</label>
                    <input
                      type="number"
                      step="1"
                      {...register('promoter_split_rate', { valueAsNumber: true })}
                      className={`w-full bg-white border rounded-xl px-4 py-3 text-brand-navy-900 font-mono font-bold focus:outline-none ${!isSplitValid ? 'border-semantic-error-600 ring-1 ring-semantic-error-600' : 'border-slate-200 focus:border-brand-gold-500'}`}
                    />
                  </div>
                </div>

                {/* 100% Stacked Progress Bar */}
                <div className="space-y-2">
                  <div className="flex justify-between text-xs font-bold">
                    <span className="text-semantic-info-500">Agent ({agentSplit}%)</span>
                    <span className="text-brand-gold-500">Promoter ({promoterSplit}%)</span>
                    <span className="text-semantic-success-600">Agency Retained ({agencySplit}%)</span>
                  </div>
                  <div className={`h-4 w-full rounded-full overflow-hidden flex ${!isSplitValid ? 'animate-pulse ring-2 ring-semantic-error-600 ring-offset-2' : ''}`}>
                    <div style={{ width: `${Math.min(agentSplit, 100)}%` }} className={`h-full ${!isSplitValid ? 'bg-semantic-error-600' : 'bg-semantic-info-500'} transition-all duration-300`}></div>
                    <div style={{ width: `${Math.min(promoterSplit, 100 - agentSplit)}%` }} className={`h-full ${!isSplitValid ? 'bg-semantic-error-500' : 'bg-brand-gold-500'} transition-all duration-300`}></div>
                    <div style={{ width: `${Math.max(0, 100 - agentSplit - promoterSplit)}%` }} className="h-full bg-semantic-success-600 transition-all duration-300"></div>
                  </div>
                  {!isSplitValid && (
                    <p className="text-xs font-bold text-semantic-error-600 text-center mt-2">Error: Splits exceed 100%</p>
                  )}
                </div>
              </div>
            </div>

            <div className="flex justify-between pt-4">
              <button 
                type="button" 
                onClick={() => setStep(2)}
                className="px-8 py-3 bg-slate-100 text-slate-600 rounded-xl font-bold text-sm tracking-wide hover:bg-slate-200 transition-colors"
              >
                Back
              </button>
              <button
                type="submit"
                disabled={mutation.isPending || !isSplitValid}
                className="flex items-center justify-center gap-2 px-8 py-3 bg-brand-gold-500 text-brand-navy-900 rounded-xl hover:bg-brand-gold-400 font-bold disabled:opacity-50 text-sm tracking-wide transition-all shadow-lg shadow-brand-gold-500/20"
              >
                {mutation.isPending ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    Executing Deal...
                  </>
                ) : (
                  'Execute Deal'
                )}
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
}
