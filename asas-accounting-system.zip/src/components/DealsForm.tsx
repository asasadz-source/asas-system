import React from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';
import { useUsers, useProperties } from '../hooks/useSupabaseData';
import toast from 'react-hot-toast';
import { Building2, DollarSign, Calendar, Save, X, User, Briefcase } from 'lucide-react';

const dealSchema = z.object({
  buyer_id: z.string().min(1, 'Buyer is required'),
  property_id: z.string().min(1, 'Property is required'),
  agent_id: z.string().min(1, 'Agent is required'),
  total_amount: z.number().min(0, 'Total amount must be positive'),
  status: z.enum(['pending', 'finalized', 'cancelled']),
  finalized_at: z.string().optional().nullable(),
});

type DealFormValues = z.infer<typeof dealSchema>;

interface DealsFormProps {
  onClose: () => void;
  initialData?: any;
}

export function DealsForm({ onClose, initialData }: DealsFormProps) {
  const { profile } = useAuth();
  const queryClient = useQueryClient();

  const { data: properties } = useProperties();
  const { data: clients } = useUsers('client');
  const { data: agents } = useUsers('agent');

  const {
    register,
    handleSubmit,
    watch,
    formState: { errors, isSubmitting },
  } = useForm<DealFormValues>({
    resolver: zodResolver(dealSchema),
    defaultValues: initialData ? {
      buyer_id: initialData.buyer_id || '',
      property_id: initialData.property_id || '',
      agent_id: initialData.agent_id || '',
      total_amount: initialData.total_amount || 0,
      status: initialData.status || 'pending',
      finalized_at: initialData.finalized_at ? new Date(initialData.finalized_at).toISOString().split('T')[0] : null,
    } : {
      status: 'pending',
      agent_id: profile?.id || '',
    },
  });

  const mutation = useMutation({
    mutationFn: async (data: DealFormValues) => {
      const payload = {
        ...data,
        finalized_at: data.status === 'finalized' && !data.finalized_at ? new Date().toISOString() : data.finalized_at ? new Date(data.finalized_at).toISOString() : null,
      };
      
      if (initialData?.id) {
        const { error } = await supabase
          .from('deals')
          .update(payload)
          .eq('id', initialData.id);
        if (error) throw error;
      } else {
        const { error } = await supabase
          .from('deals')
          .insert(payload);
        if (error) throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['deals'] });
      toast.success(initialData?.id ? 'Deal updated successfully' : 'Deal created successfully');
      onClose();
    },
    onError: (error: any) => {
      toast.error(error.message || 'Failed to save deal');
    },
  });

  const onSubmit = (data: DealFormValues) => {
    mutation.mutate(data);
  };

  return (
    <div className="bg-white border border-slate-200 rounded-3xl p-8 shadow-xl">
      <div className="flex justify-between items-center mb-8 border-b border-slate-100 pb-6">
        <h3 className="text-2xl font-display font-bold text-brand-navy-900 flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-brand-gold-500/10 flex items-center justify-center">
            <Building2 className="w-5 h-5 text-brand-gold-500" />
          </div>
          {initialData?.id ? 'Edit Deal' : 'New Deal'}
        </h3>
        <button
          onClick={onClose}
          className="text-slate-400 hover:text-brand-navy-900 transition-colors p-2 rounded-xl hover:bg-slate-50"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Client Selection */}
          <div>
            <label className="block text-sm font-bold text-brand-navy-900 mb-1 flex items-center gap-2">
              <User className="w-4 h-4 text-slate-400" />
              Buyer (Client)
            </label>
            <select
              {...register('buyer_id')}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-brand-navy-900 focus:outline-none focus:ring-2 focus:ring-brand-gold-500/50 focus:border-brand-gold-500 transition-colors font-medium"
            >
              <option value="">Select Client</option>
              {clients?.map(client => (
                <option key={client.id} value={client.id}>{client.name}</option>
              ))}
            </select>
            {errors.buyer_id && <p className="mt-1 text-sm text-red-400">{errors.buyer_id.message}</p>}
          </div>

          {/* Property Selection */}
          <div>
            <label className="block text-sm font-bold text-brand-navy-900 mb-1 flex items-center gap-2">
              <Building2 className="w-4 h-4 text-slate-400" />
              Property
            </label>
            <select
              {...register('property_id')}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-brand-navy-900 focus:outline-none focus:ring-2 focus:ring-brand-gold-500/50 focus:border-brand-gold-500 transition-colors font-medium"
            >
              <option value="">Select Property</option>
              {properties?.map(property => (
                <option key={property.id} value={property.id}>{property.location} - {property.type}</option>
              ))}
            </select>
            {errors.property_id && <p className="mt-1 text-sm text-red-400">{errors.property_id.message}</p>}
          </div>

          {/* Total Amount */}
          <div>
            <label className="block text-sm font-bold text-brand-navy-900 mb-1">
              Total Amount (DZD)
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <DollarSign className="h-4 w-4 text-slate-400" />
              </div>
              <input
                type="number"
                step="0.01"
                {...register('total_amount', { valueAsNumber: true })}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-10 pr-4 py-3 text-brand-navy-900 focus:outline-none focus:ring-2 focus:ring-brand-gold-500/50 focus:border-brand-gold-500 transition-colors font-mono font-bold"
                placeholder="0.00"
              />
            </div>
            {errors.total_amount && <p className="mt-1 text-sm text-semantic-error-600">{errors.total_amount.message}</p>}
          </div>

          {/* Agent Selection (Admin only) */}
          <div>
            <label className="block text-sm font-bold text-brand-navy-900 mb-1">
              Assigned Agent
            </label>
            <select
              {...register('agent_id')}
              disabled={profile?.role !== 'admin'}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-brand-navy-900 focus:outline-none focus:ring-2 focus:ring-brand-gold-500/50 focus:border-brand-gold-500 transition-colors disabled:opacity-50 font-medium"
            >
              <option value="">Select Agent</option>
              {agents?.map(agent => (
                <option key={agent.id} value={agent.id}>{agent.name}</option>
              ))}
            </select>
            {errors.agent_id && <p className="mt-1 text-sm text-red-400">{errors.agent_id.message}</p>}
          </div>

          {/* Status */}
          <div>
            <label className="block text-sm font-bold text-brand-navy-900 mb-1">
              Status
            </label>
            <select
              {...register('status')}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-brand-navy-900 focus:outline-none focus:ring-2 focus:ring-brand-gold-500/50 focus:border-brand-gold-500 transition-colors font-medium"
            >
              <option value="pending">Pending</option>
              <option value="finalized">Finalized</option>
              <option value="cancelled">Cancelled</option>
            </select>
            {errors.status && <p className="mt-1 text-sm text-semantic-error-600">{errors.status.message}</p>}
          </div>
          
          {/* Finalized Date */}
          {watch('status') === 'finalized' && (
            <div>
              <label className="block text-sm font-bold text-brand-navy-900 mb-1">
                Finalized Date
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Calendar className="h-4 w-4 text-slate-400" />
                </div>
                <input
                  type="date"
                  {...register('finalized_at')}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-10 pr-4 py-3 text-brand-navy-900 focus:outline-none focus:ring-2 focus:ring-brand-gold-500/50 focus:border-brand-gold-500 transition-colors font-medium"
                />
              </div>
              {errors.finalized_at && <p className="mt-1 text-sm text-semantic-error-600">{errors.finalized_at.message}</p>}
            </div>
          )}
        </div>

        <div className="flex justify-end gap-3 pt-6 border-t border-slate-100">
          <button
            type="button"
            onClick={onClose}
            className="px-6 py-3 text-sm font-bold text-slate-600 hover:text-brand-navy-900 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors tracking-wide"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={isSubmitting}
            className="flex items-center gap-2 px-8 py-3 text-sm font-bold text-brand-navy-900 bg-brand-gold-500 hover:bg-brand-gold-400 rounded-xl transition-colors disabled:opacity-50 disabled:cursor-not-allowed shadow-lg shadow-brand-gold-500/20 tracking-wide"
          >
            {isSubmitting ? (
              <div className="w-4 h-4 border-2 border-brand-navy-900/30 border-t-brand-navy-900 rounded-full animate-spin" />
            ) : (
              <Save className="w-4 h-4" />
            )}
            {initialData?.id ? 'Update Deal' : 'Save Deal'}
          </button>
        </div>
      </form>
    </div>
  );
}

