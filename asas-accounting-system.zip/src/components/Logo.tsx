import React from 'react';

export function Logo({ className = "w-32 h-auto" }: { className?: string }) {
  return (
    <svg viewBox="0 0 200 200" className={className} fill="none" xmlns="http://www.w3.org/2000/svg" aria-label="ASAS Logo" role="img">
      {/* The main 'A' shape */}
      <g stroke="currentColor" strokeWidth="16" strokeLinecap="butt" strokeLinejoin="miter">
        {/* Outer peak */}
        <polyline points="45,115 100,25 155,115" />
        {/* Inner parallel line on the left */}
        <line x1="75" y1="115" x2="100" y2="74" />
      </g>
      
      {/* Green Diamond */}
      <polygon points="100,95 108,103 100,111 92,103" fill="#10b981" />
      
      {/* ASAS Text */}
      <text x="100" y="160" fontFamily="sans-serif" fontWeight="800" fontSize="46" textAnchor="middle" fill="currentColor" letterSpacing="0.05em">ASAS</text>
      
      {/* Subtitle */}
      <text x="100" y="180" fontFamily="sans-serif" fontWeight="300" fontSize="12" textAnchor="middle" fill="#94a3b8" letterSpacing="0.05em">MARKETING REAL ESTATE</text>
    </svg>
  );
}
