import React, { useState } from 'react';
import { useTransactions, useDeals, useAgents, useCampaigns } from '../hooks/useSupabaseData';
import { formatCurrency } from '../utils';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, LineChart, Line } from 'recharts';
import { format, parseISO } from 'date-fns';
import { Loader2, TrendingUp, Users, Megaphone, PieChart } from 'lucide-react';
import { Deal, MarketingCampaign, AppUser } from '../types/supabase';

export function Reports() {
  const [reportType, setReportType] = useState<'profit' | 'agent' | 'marketing'>('profit');

  const { data: transactions, isLoading: transLoading } = useTransactions();
  const { data: deals, isLoading: dealsLoading } = useDeals();
  const { data: agents, isLoading: agentsLoading } = useAgents();
  const { data: campaigns, isLoading: campaignsLoading } = useCampaigns();

  if (transLoading || dealsLoading || agentsLoading || campaignsLoading) {
    return (
      <div className="flex flex-col items-center justify-center p-20 space-y-4">
        <Loader2 className="w-10 h-10 animate-spin text-brand-gold" />
        <p className="text-slate-400 font-medium animate-pulse">Generating reports...</p>
      </div>
    );
  }

  // Aggregate data for Profit Report
  const profitData = (transactions || []).reduce((acc, trans) => {
    const month = trans.created_at.substring(0, 7);
    if (!acc[month]) acc[month] = { month, revenues: 0, expenses: 0, profit: 0 };
    
    if (trans.type === 'PAYMENT') {
      acc[month].revenues += trans.amount;
      acc[month].profit += trans.amount;
    } else {
      acc[month].expenses += trans.amount;
      acc[month].profit -= trans.amount;
    }
    return acc;
  }, {} as Record<string, any>);

  const profitChartData = Object.values(profitData).sort((a, b) => a.month.localeCompare(b.month)).map(d => ({
    ...d,
    displayMonth: format(parseISO(`${d.month}-01`), 'MMM yyyy')
  }));

  // Aggregate data for Agent Performance
  const agentData = (agents || []).map((agent: AppUser) => {
    const agentSales = (deals || []).filter(s => s.agent_id === agent.id);
    const totalSalesValue = agentSales.reduce((sum, s) => sum + (s.total_amount || 0), 0);
    const totalCommissionEarned = 0; // Not supported directly in current schema without joining commissions
    const totalCommissionPaid = 0; // Not supported directly in current schema without joining commissions

    return {
      name: agent.name,
      salesCount: agentSales.length,
      totalSalesValue,
      totalCommissionEarned,
      totalCommissionPaid,
      pendingCommission: totalCommissionEarned - totalCommissionPaid
    };
  }).sort((a, b) => b.totalSalesValue - a.totalSalesValue);

  // Aggregate data for Marketing ROI
  const marketingData = (campaigns || []).map((campaign: MarketingCampaign) => {
    const revenueGenerated = 0; // Not supported in current schema
    const roi = campaign.budget > 0 ? ((revenueGenerated - campaign.budget) / campaign.budget) * 100 : 0;
    return {
      name: campaign.name,
      budget: campaign.budget,
      revenueGenerated,
      roi: parseFloat(roi.toFixed(2))
    };
  });

  return (
    <div className="space-y-8 pb-10">
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-6">
        <div>
          <h2 className="text-3xl lg:text-4xl font-display font-bold text-sidebar-dark tracking-tight">Financial Reports</h2>
          <p className="text-slate-500 font-medium mt-1">Analyze performance, ROI, and agent productivity</p>
        </div>
        
        <div className="flex p-1.5 bg-white rounded-2xl border border-slate-200 shadow-sm w-full lg:w-auto">
          <button
            onClick={() => setReportType('profit')}
            className={`flex-1 lg:flex-none px-6 py-2.5 rounded-xl text-xs font-bold uppercase tracking-widest transition-all ${
              reportType === 'profit' ? 'bg-sidebar-dark text-white shadow-lg shadow-slate-200' : 'text-slate-400 hover:text-sidebar-dark hover:bg-slate-50'
            }`}
          >
            Profit
          </button>
          <button
            onClick={() => setReportType('agent')}
            className={`flex-1 lg:flex-none px-6 py-2.5 rounded-xl text-xs font-bold uppercase tracking-widest transition-all ${
              reportType === 'agent' ? 'bg-sidebar-dark text-white shadow-lg shadow-slate-200' : 'text-slate-400 hover:text-sidebar-dark hover:bg-slate-50'
            }`}
          >
            Agents
          </button>
          <button
            onClick={() => setReportType('marketing')}
            className={`flex-1 lg:flex-none px-6 py-2.5 rounded-xl text-xs font-bold uppercase tracking-widest transition-all ${
              reportType === 'marketing' ? 'bg-sidebar-dark text-white shadow-lg shadow-slate-200' : 'text-slate-400 hover:text-sidebar-dark hover:bg-slate-50'
            }`}
          >
            Marketing
          </button>
        </div>
      </div>

      <div className="bg-white p-8 lg:p-12 rounded-[2.5rem] shadow-sm border border-slate-200">
        {reportType === 'profit' && (
          <div className="space-y-16">
            <div className="space-y-8">
              <div className="flex items-center gap-4">
                <div className="w-1.5 h-8 bg-brand-gold rounded-full" />
                <h3 className="text-2xl font-display font-bold text-sidebar-dark">Monthly Revenue vs Expenses</h3>
              </div>
              <div className="h-[400px] w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={profitChartData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                    <XAxis dataKey="displayMonth" stroke="#94a3b8" fontSize={11} fontWeight={600} axisLine={false} tickLine={false} />
                    <YAxis stroke="#94a3b8" fontSize={11} fontWeight={600} axisLine={false} tickLine={false} tickFormatter={(value) => `${value / 1000}k`} />
                    <Tooltip 
                      formatter={(value: number) => formatCurrency(value)}
                      contentStyle={{ backgroundColor: '#0F172A', borderRadius: '1rem', border: 'none', boxShadow: '0 20px 25px -5px rgb(0 0 0 / 0.1)', padding: '12px 16px' }}
                      itemStyle={{ color: '#fff', fontSize: '12px', fontWeight: 'bold' }}
                      labelStyle={{ color: '#94a3b8', fontSize: '10px', marginBottom: '4px', textTransform: 'uppercase', fontWeight: 'bold', letterSpacing: '0.05em' }}
                    />
                    <Legend wrapperStyle={{ paddingTop: '30px' }} iconType="circle" />
                    <Bar dataKey="revenues" name="Revenues" fill="#10b981" radius={[6, 6, 0, 0]} barSize={32} />
                    <Bar dataKey="expenses" name="Expenses" fill="#f43f5e" radius={[6, 6, 0, 0]} barSize={32} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
            
            <div className="space-y-8">
              <div className="flex items-center gap-4">
                <div className="w-1.5 h-8 bg-emerald-500 rounded-full" />
                <h3 className="text-2xl font-display font-bold text-sidebar-dark">Net Profit Trend</h3>
              </div>
              <div className="h-[300px] w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={profitChartData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                    <XAxis dataKey="displayMonth" stroke="#94a3b8" fontSize={11} fontWeight={600} axisLine={false} tickLine={false} />
                    <YAxis stroke="#94a3b8" fontSize={11} fontWeight={600} axisLine={false} tickLine={false} tickFormatter={(value) => `${value / 1000}k`} />
                    <Tooltip 
                      formatter={(value: number) => formatCurrency(value)}
                      contentStyle={{ backgroundColor: '#0F172A', borderRadius: '1rem', border: 'none', boxShadow: '0 20px 25px -5px rgb(0 0 0 / 0.1)', padding: '12px 16px' }}
                      itemStyle={{ color: '#fff', fontSize: '12px', fontWeight: 'bold' }}
                      labelStyle={{ color: '#94a3b8', fontSize: '10px', marginBottom: '4px', textTransform: 'uppercase', fontWeight: 'bold', letterSpacing: '0.05em' }}
                    />
                    <Legend wrapperStyle={{ paddingTop: '30px' }} iconType="circle" />
                    <Line type="monotone" dataKey="profit" name="Net Profit" stroke="#Cfb53b" strokeWidth={4} dot={{ r: 6, fill: '#Cfb53b', strokeWidth: 3, stroke: '#fff' }} activeDot={{ r: 8, strokeWidth: 0 }} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
        )}

        {reportType === 'agent' && (
          <div className="space-y-8">
            <div className="flex items-center gap-4">
              <div className="w-1.5 h-8 bg-brand-gold rounded-full" />
              <h3 className="text-2xl font-display font-bold text-sidebar-dark">Agent Performance Overview</h3>
            </div>
            <div className="overflow-x-auto -mx-8 lg:-mx-12">
              <table className="w-full text-left border-collapse min-w-[800px]">
                <thead>
                  <tr className="bg-slate-50/50 text-[10px] text-slate-400 uppercase tracking-[0.2em] font-bold">
                    <th className="px-8 py-5">Agent Name</th>
                    <th className="px-8 py-5 text-center">Sales</th>
                    <th className="px-8 py-5 text-right">Total Value</th>
                    <th className="px-8 py-5 text-right">Commission</th>
                    <th className="px-8 py-5 text-right">Paid</th>
                    <th className="px-8 py-5 text-right">Pending</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-50">
                  {agentData.map((agent, index) => (
                    <tr key={index} className="hover:bg-slate-50/50 transition-colors">
                      <td className="px-8 py-6 font-bold text-sidebar-dark">{agent.name}</td>
                      <td className="px-8 py-6 text-center font-bold text-slate-400">{agent.salesCount}</td>
                      <td className="px-8 py-6 text-right font-bold text-sidebar-dark">{formatCurrency(agent.totalSalesValue)}</td>
                      <td className="px-8 py-6 text-right font-bold text-emerald-600">{formatCurrency(agent.totalCommissionEarned)}</td>
                      <td className="px-8 py-6 text-right font-bold text-slate-400">{formatCurrency(agent.totalCommissionPaid)}</td>
                      <td className="px-8 py-6 text-right font-bold text-rose-500">{formatCurrency(agent.pendingCommission)}</td>
                    </tr>
                  ))}
                  {agentData.length === 0 && (
                    <tr>
                      <td colSpan={6} className="px-8 py-20 text-center text-slate-400 font-medium">No agent data available.</td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {reportType === 'marketing' && (
          <div className="space-y-16">
            <div className="space-y-8">
              <div className="flex items-center gap-4">
                <div className="w-1.5 h-8 bg-rose-500 rounded-full" />
                <h3 className="text-2xl font-display font-bold text-sidebar-dark">Marketing Campaign ROI</h3>
              </div>
              <div className="h-[400px] w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={marketingData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                    <XAxis dataKey="name" stroke="#94a3b8" fontSize={11} fontWeight={600} axisLine={false} tickLine={false} />
                    <YAxis stroke="#94a3b8" fontSize={11} fontWeight={600} axisLine={false} tickLine={false} tickFormatter={(value) => `${value / 1000}k`} />
                    <Tooltip 
                      formatter={(value: number) => formatCurrency(value)}
                      contentStyle={{ backgroundColor: '#0F172A', borderRadius: '1rem', border: 'none', boxShadow: '0 20px 25px -5px rgb(0 0 0 / 0.1)', padding: '12px 16px' }}
                      itemStyle={{ color: '#fff', fontSize: '12px', fontWeight: 'bold' }}
                      labelStyle={{ color: '#94a3b8', fontSize: '10px', marginBottom: '4px', textTransform: 'uppercase', fontWeight: 'bold', letterSpacing: '0.05em' }}
                    />
                    <Legend wrapperStyle={{ paddingTop: '30px' }} iconType="circle" />
                    <Bar dataKey="budget" name="Budget Spent" fill="#f43f5e" radius={[6, 6, 0, 0]} barSize={32} />
                    <Bar dataKey="revenueGenerated" name="Revenue Generated" fill="#10b981" radius={[6, 6, 0, 0]} barSize={32} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
            
            <div className="overflow-x-auto -mx-8 lg:-mx-12">
              <table className="w-full text-left border-collapse min-w-[800px]">
                <thead>
                  <tr className="bg-slate-50/50 text-[10px] text-slate-400 uppercase tracking-[0.2em] font-bold">
                    <th className="px-8 py-5">Campaign Name</th>
                    <th className="px-8 py-5 text-right">Budget Spent</th>
                    <th className="px-8 py-5 text-right">Revenue Generated</th>
                    <th className="px-8 py-5 text-right">ROI (%)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-50">
                  {marketingData.map((campaign, index) => (
                    <tr key={index} className="hover:bg-slate-50/50 transition-colors">
                      <td className="px-8 py-6 font-bold text-sidebar-dark">{campaign.name}</td>
                      <td className="px-8 py-6 text-right font-bold text-rose-500">{formatCurrency(campaign.budget)}</td>
                      <td className="px-8 py-6 text-right font-bold text-emerald-600">{formatCurrency(campaign.revenueGenerated)}</td>
                      <td className="px-8 py-6 text-right">
                        <span className={`inline-flex items-center px-4 py-1.5 rounded-full text-[10px] font-bold uppercase tracking-widest ${
                          campaign.roi >= 0 ? 'bg-emerald-50 text-emerald-600 border border-emerald-100' : 'bg-rose-50 text-rose-600 border border-rose-100'
                        }`}>
                          {campaign.roi >= 0 ? '+' : ''}{campaign.roi}%
                        </span>
                      </td>
                    </tr>
                  ))}
                  {marketingData.length === 0 && (
                    <tr>
                      <td colSpan={4} className="px-8 py-20 text-center text-slate-400 font-medium">No marketing data available.</td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

