import React, { useState } from 'react';
import { useExpenses, useUsers } from '../hooks/useSupabaseData';
import { formatCurrency } from '../utils';
import { Plus, Search, X, Trash2, ArrowDownUp, Filter, Loader2, Receipt, User, ShieldCheck } from 'lucide-react';
import { format, parseISO } from 'date-fns';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '../lib/supabase';
import toast from 'react-hot-toast';
import { useAuth } from '../context/AuthContext';

const EXPENSE_CATEGORIES = [
  "marketing",
  "maintenance",
  "other"
] as const;

export function Expenses() {
  const { profile } = useAuth();
  const queryClient = useQueryClient();
  const [isAdding, setIsAdding] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterMonth, setFilterMonth] = useState<string>('all');
  const [sortValueDesc, setSortValueDesc] = useState(true);
  const [selectedCategory, setSelectedCategory] = useState<string>(EXPENSE_CATEGORIES[0]);
  
  const { data: expenses, isLoading: transLoading } = useExpenses();
  const { data: users } = useUsers();

  const addMutation = useMutation({
    mutationFn: async (newExpense: any) => {
      const { error } = await supabase
        .from('expenses')
        .insert({
          ...newExpense,
          created_by: profile?.id
        });
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['expenses'] });
      toast.success('Expense recorded successfully');
      setIsAdding(false);
    },
    onError: (error: any) => {
      toast.error(error.message || 'Failed to record expense');
    }
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from('expenses')
        .delete()
        .eq('id', id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['expenses'] });
      toast.success('Expense deleted');
    },
    onError: (error: any) => {
      toast.error(error.message || 'Failed to delete expense');
    }
  });

  const handleAddExpense = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const data = {
      category: formData.get('category'),
      amount: Number(formData.get('amount')),
      description: formData.get('description'),
      created_at: new Date(formData.get('date') as string).toISOString(),
    };
    addMutation.mutate(data);
  };

  const availableMonths = Array.from(new Set(expenses?.map(e => e.created_at.substring(0, 7)) || [])).sort().reverse();

  let filteredExpenses = expenses?.filter(e => 
    (e.description?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    e.category?.toLowerCase().includes(searchTerm.toLowerCase())) &&
    (filterMonth === 'all' || e.created_at.startsWith(filterMonth))
  ) || [];

  filteredExpenses.sort((a, b) => {
    if (sortValueDesc) {
      return Math.abs(b.amount || 0) - Math.abs(a.amount || 0);
    } else {
      return Math.abs(a.amount || 0) - Math.abs(b.amount || 0);
    }
  });

  if (transLoading) {
    return (
      <div className="flex flex-col items-center justify-center p-20 space-y-4">
        <Loader2 className="w-10 h-10 animate-spin text-brand-gold" />
        <p className="text-slate-400 font-medium animate-pulse">Loading expenses...</p>
      </div>
    );
  }

  return (
    <div className="space-y-8 pb-10">
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-6">
        <div className="flex flex-col sm:flex-row gap-4 w-full lg:w-auto flex-1">
          <div className="relative w-full sm:w-80">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 w-5 h-5" />
            <input
              type="text"
              placeholder="Search expenses..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-12 pr-4 py-3 bg-white border border-slate-200 rounded-2xl text-sidebar-dark placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-brand-gold/20 focus:border-brand-gold transition-all shadow-sm"
            />
          </div>
          
          <div className="flex gap-3 w-full sm:w-auto">
            <div className="relative flex-1 sm:w-48">
              <Filter className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 w-4 h-4" />
              <select
                value={filterMonth}
                onChange={(e) => setFilterMonth(e.target.value)}
                className="w-full pl-10 pr-4 py-3 bg-white border border-slate-200 rounded-2xl text-sidebar-dark font-medium focus:outline-none focus:ring-2 focus:ring-brand-gold/20 focus:border-brand-gold transition-all shadow-sm appearance-none"
              >
                <option value="all">All Months</option>
                {availableMonths.map(month => (
                  <option key={month} value={month}>
                    {format(parseISO(`${month}-01`), 'MMMM yyyy')}
                  </option>
                ))}
              </select>
            </div>
            
            <button
              onClick={() => setSortValueDesc(!sortValueDesc)}
              className="flex items-center justify-center w-12 h-12 bg-white border border-slate-200 rounded-2xl text-slate-400 hover:text-brand-gold hover:border-brand-gold/30 transition-all shadow-sm"
              title={sortValueDesc ? "Sort Low to High" : "Sort High to Low"}
            >
              <ArrowDownUp className={`w-5 h-5 transition-transform ${sortValueDesc ? '' : 'rotate-180'}`} />
            </button>
          </div>
        </div>

        <button
          onClick={() => setIsAdding(true)}
          className="flex items-center space-x-2 bg-brand-gold text-sidebar-dark px-8 py-3.5 rounded-2xl hover:bg-brand-gold/90 transition-all shadow-xl shadow-brand-gold/20 w-full lg:w-auto justify-center font-bold text-sm tracking-wide"
        >
          <Plus className="w-5 h-5" />
          <span>ADD EXPENSE</span>
        </button>
      </div>

      {isAdding && (
        <div className="bg-white border border-slate-200 p-8 rounded-3xl shadow-xl animate-in fade-in slide-in-from-top-4 duration-300">
          <div className="flex justify-between items-center mb-8 border-b border-slate-100 pb-6">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-brand-gold/10 flex items-center justify-center text-brand-gold">
                <Receipt className="w-5 h-5" />
              </div>
              <h3 className="text-2xl font-display font-bold text-sidebar-dark">New Expense Record</h3>
            </div>
            <button onClick={() => setIsAdding(false)} className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-slate-100 text-slate-400 transition-colors">
              <X className="w-6 h-6" />
            </button>
          </div>
          <form onSubmit={handleAddExpense} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div>
              <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-2">Date</label>
              <input
                type="date"
                name="date"
                required
                defaultValue={format(new Date(), 'yyyy-MM-dd')}
                className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-5 py-3.5 text-sidebar-dark font-medium focus:outline-none focus:ring-2 focus:ring-brand-gold/20 focus:border-brand-gold transition-all"
              />
            </div>
            <div>
              <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-2">Category</label>
              <select
                name="category"
                required
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-5 py-3.5 text-sidebar-dark font-medium focus:outline-none focus:ring-2 focus:ring-brand-gold/20 focus:border-brand-gold transition-all appearance-none"
              >
                {EXPENSE_CATEGORIES.map(cat => (
                  <option key={cat} value={cat}>{cat}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-2">Amount (DZD)</label>
              <input
                type="number"
                name="amount"
                required
                min="0"
                step="0.01"
                className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-5 py-3.5 text-sidebar-dark font-bold focus:outline-none focus:ring-2 focus:ring-brand-gold/20 focus:border-brand-gold transition-all"
                placeholder="0.00"
              />
            </div>
            <div className="lg:col-span-3">
              <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-2">Description</label>
              <input
                type="text"
                name="description"
                required
                className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-5 py-3.5 text-sidebar-dark font-medium placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-brand-gold/20 focus:border-brand-gold transition-all"
                placeholder="Brief description of the expense..."
              />
            </div>
            <div className="lg:col-span-3 flex justify-end gap-4 mt-6 pt-8 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setIsAdding(false)}
                className="px-8 py-3.5 text-slate-500 hover:text-sidebar-dark font-bold text-sm tracking-wide transition-colors"
              >
                CANCEL
              </button>
              <button
                type="submit"
                disabled={addMutation.isPending}
                className="px-10 py-3.5 bg-brand-gold text-sidebar-dark rounded-2xl hover:bg-brand-gold/90 font-bold text-sm tracking-wide transition-all shadow-xl shadow-brand-gold/20 disabled:opacity-50"
              >
                {addMutation.isPending ? 'SAVING...' : 'SAVE EXPENSE'}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Desktop Table View */}
      <div className="hidden md:block bg-white border border-slate-200 rounded-3xl shadow-sm overflow-hidden">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-slate-50/50 border-b border-slate-100 text-[10px] uppercase tracking-[0.2em] text-slate-400 font-bold">
              <th className="px-8 py-5">Expense Details</th>
              <th className="px-8 py-5">Date & Performed By</th>
              <th className="px-8 py-5 text-right">Amount</th>
              {profile?.role === 'admin' && <th className="px-8 py-5 text-right">Actions</th>}
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-50">
            {filteredExpenses.map((expense) => (
              <tr key={expense.id} className="hover:bg-slate-50/50 transition-colors group">
                <td className="px-8 py-6">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-2xl bg-slate-50 border border-slate-100 flex items-center justify-center text-slate-400 group-hover:text-brand-gold transition-colors">
                      <Receipt className="w-6 h-6" />
                    </div>
                    <div>
                      <div className="text-sidebar-dark font-bold text-sm">{expense.description}</div>
                      <div className="flex items-center gap-2 mt-1.5">
                        <span className="text-[9px] px-2 py-0.5 rounded-full bg-slate-100 text-slate-500 font-bold uppercase tracking-widest">
                          {expense.category}
                        </span>
                      </div>
                    </div>
                  </div>
                </td>
                <td className="px-8 py-6">
                  <div className="flex flex-col">
                    <span className="text-sidebar-dark text-sm font-bold">
                      {format(parseISO(expense.created_at), 'MMM dd, yyyy')}
                    </span>
                    <span className="text-slate-400 text-[10px] flex items-center gap-1.5 mt-1 font-bold uppercase tracking-widest">
                      <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
                      By: {expense.creator?.name || 'System'}
                    </span>
                  </div>
                </td>
                <td className="px-8 py-6 text-right font-bold text-rose-600 text-lg">
                  {formatCurrency(expense.amount || 0)}
                </td>
                {profile?.role === 'admin' && (
                  <td className="px-8 py-6 text-right">
                    <button 
                      onClick={() => {
                        if (window.confirm('Delete this expense?')) {
                          deleteMutation.mutate(expense.id);
                        }
                      }}
                      className="w-10 h-10 flex items-center justify-center text-slate-300 hover:text-rose-500 hover:bg-rose-50 rounded-xl transition-all opacity-0 group-hover:opacity-100"
                      title="Delete Expense"
                    >
                      <Trash2 className="w-5 h-5" />
                    </button>
                  </td>
                )}
              </tr>
            ))}
            {filteredExpenses.length === 0 && (
              <tr>
                <td colSpan={profile?.role === 'admin' ? 4 : 3} className="px-8 py-20 text-center">
                  <p className="text-slate-400 font-medium">No expenses found matching your criteria.</p>
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Mobile Card View */}
      <div className="md:hidden space-y-4">
        {filteredExpenses.map((expense) => (
          <div key={expense.id} className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-4">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-slate-50 flex items-center justify-center text-brand-gold">
                  <Receipt className="w-5 h-5" />
                </div>
                <div>
                  <p className="text-sidebar-dark font-bold text-sm leading-tight">{expense.description}</p>
                  <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-1">{expense.category}</p>
                </div>
              </div>
              <p className="font-bold text-rose-600">{formatCurrency(expense.amount || 0)}</p>
            </div>
            
            <div className="flex items-center justify-between pt-4 border-t border-slate-50">
              <div className="flex flex-col">
                <span className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Date</span>
                <span className="text-xs font-bold text-sidebar-dark">{format(parseISO(expense.created_at), 'MMM dd, yyyy')}</span>
              </div>
              <div className="flex flex-col text-right">
                <span className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">By</span>
                <span className="text-xs font-bold text-sidebar-dark">{expense.creator?.name?.split(' ')[0] || 'System'}</span>
              </div>
            </div>

            {profile?.role === 'admin' && (
              <button 
                onClick={() => {
                  if (window.confirm('Delete this expense?')) {
                    deleteMutation.mutate(expense.id);
                  }
                }}
                className="w-full py-3 flex items-center justify-center gap-2 text-rose-500 bg-rose-50 rounded-2xl font-bold text-xs uppercase tracking-widest"
              >
                <Trash2 className="w-4 h-4" />
                Delete Record
              </button>
            )}
          </div>
        ))}
        {filteredExpenses.length === 0 && (
          <div className="text-center py-12 bg-white rounded-3xl border border-dashed border-slate-200">
            <p className="text-slate-400 font-medium">No expenses found.</p>
          </div>
        )}
      </div>
    </div>
  );
}

