export type Database = {
  public: {
    Tables: {
      users: {
        Row: {
          id: string
          name: string
          email: string
          phone: string | null
          role: 'admin' | 'agent' | 'client'
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          name: string
          email: string
          phone?: string | null
          role: 'admin' | 'agent' | 'client'
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          name?: string
          email?: string
          phone?: string | null
          role?: 'admin' | 'agent' | 'client'
          created_at?: string
          updated_at?: string
        }
        Relationships: []
      }
      properties: {
        Row: {
          id: string
          type: 'apartment' | 'villa' | 'commercial'
          location: string
          price: number
          status: 'available' | 'reserved' | 'sold'
          created_by: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          type: 'apartment' | 'villa' | 'commercial'
          location: string
          price: number
          status?: 'available' | 'reserved' | 'sold'
          created_by?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          type?: 'apartment' | 'villa' | 'commercial'
          location?: string
          price?: number
          status?: 'available' | 'reserved' | 'sold'
          created_by?: string | null
          created_at?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "properties_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          }
        ]
      }
      property_features: {
        Row: {
          id: string
          property_id: string | null
          rooms: number | null
          bathrooms: number | null
          surface: number | null
          balcony: boolean
          parking: boolean
          elevator: boolean
        }
        Insert: {
          id?: string
          property_id?: string | null
          rooms?: number | null
          bathrooms?: number | null
          surface?: number | null
          balcony?: boolean
          parking?: boolean
          elevator?: boolean
        }
        Update: {
          id?: string
          property_id?: string | null
          rooms?: number | null
          bathrooms?: number | null
          surface?: number | null
          balcony?: boolean
          parking?: boolean
          elevator?: boolean
        }
        Relationships: [
          {
            foreignKeyName: "property_features_property_id_fkey"
            columns: ["property_id"]
            isOneToOne: false
            referencedRelation: "properties"
            referencedColumns: ["id"]
          }
        ]
      }
      deals: {
        Row: {
          id: string
          property_id: string | null
          buyer_id: string | null
          agent_id: string | null
          status: 'pending' | 'finalized' | 'cancelled'
          total_amount: number | null
          finalized_at: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          property_id?: string | null
          buyer_id?: string | null
          agent_id?: string | null
          status?: 'pending' | 'finalized' | 'cancelled'
          total_amount?: number | null
          finalized_at?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          property_id?: string | null
          buyer_id?: string | null
          agent_id?: string | null
          status?: 'pending' | 'finalized' | 'cancelled'
          total_amount?: number | null
          finalized_at?: string | null
          created_at?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "deals_property_id_fkey"
            columns: ["property_id"]
            isOneToOne: false
            referencedRelation: "properties"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "deals_buyer_id_fkey"
            columns: ["buyer_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "deals_agent_id_fkey"
            columns: ["agent_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          }
        ]
      }
      commissions: {
        Row: {
          id: string
          deal_id: string | null
          agent_id: string | null
          amount: number | null
          status: 'pending' | 'paid'
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          deal_id?: string | null
          agent_id?: string | null
          amount?: number | null
          status?: 'pending' | 'paid'
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          deal_id?: string | null
          agent_id?: string | null
          amount?: number | null
          status?: 'pending' | 'paid'
          created_at?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "commissions_deal_id_fkey"
            columns: ["deal_id"]
            isOneToOne: false
            referencedRelation: "deals"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "commissions_agent_id_fkey"
            columns: ["agent_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          }
        ]
      }
      expenses: {
        Row: {
          id: string
          category: 'marketing' | 'maintenance' | 'other'
          description: string | null
          amount: number | null
          created_by: string | null
          created_at: string
        }
        Insert: {
          id?: string
          category: 'marketing' | 'maintenance' | 'other'
          description?: string | null
          amount?: number | null
          created_by?: string | null
          created_at?: string
        }
        Update: {
          id?: string
          category?: 'marketing' | 'maintenance' | 'other'
          description?: string | null
          amount?: number | null
          created_by?: string | null
          created_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "expenses_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          }
        ]
      }
      payments: {
        Row: {
          id: string
          deal_id: string | null
          type: 'deposit' | 'final' | 'commission'
          amount: number | null
          status: 'pending' | 'completed'
          paid_at: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          deal_id?: string | null
          type: 'deposit' | 'final' | 'commission'
          amount?: number | null
          status?: 'pending' | 'completed'
          paid_at?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          deal_id?: string | null
          type?: 'deposit' | 'final' | 'commission'
          amount?: number | null
          status?: 'pending' | 'completed'
          paid_at?: string | null
          created_at?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "payments_deal_id_fkey"
            columns: ["deal_id"]
            isOneToOne: false
            referencedRelation: "deals"
            referencedColumns: ["id"]
          }
        ]
      }
      property_images: {
        Row: {
          id: string
          property_id: string | null
          url: string
          created_at: string
        }
        Insert: {
          id?: string
          property_id?: string | null
          url: string
          created_at?: string
        }
        Update: {
          id?: string
          property_id?: string | null
          url?: string
          created_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "property_images_property_id_fkey"
            columns: ["property_id"]
            isOneToOne: false
            referencedRelation: "properties"
            referencedColumns: ["id"]
          }
        ]
      }
      audit_log: {
        Row: {
          id: number
          table_name: string
          record_id: string | null
          action: 'insert' | 'update' | 'delete'
          old_data: any | null
          new_data: any | null
          performed_by: string | null
          performed_at: string
        }
        Insert: {
          id?: number
          table_name: string
          record_id?: string | null
          action: 'insert' | 'update' | 'delete'
          old_data?: any | null
          new_data?: any | null
          performed_by?: string | null
          performed_at?: string
        }
        Update: {
          id?: number
          table_name?: string
          record_id?: string | null
          action?: 'insert' | 'update' | 'delete'
          old_data?: any | null
          new_data?: any | null
          performed_by?: string | null
          performed_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "audit_log_performed_by_fkey"
            columns: ["performed_by"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          }
        ]
      }
      commission_audit_log: {
        Row: {
          id: number
          commission_id: string | null
          old_amount: number | null
          new_amount: number | null
          changed_by: string | null
          changed_at: string
        }
        Insert: {
          id?: number
          commission_id?: string | null
          old_amount?: number | null
          new_amount?: number | null
          changed_by?: string | null
          changed_at?: string
        }
        Update: {
          id?: number
          commission_id?: string | null
          old_amount?: number | null
          new_amount?: number | null
          changed_by?: string | null
          changed_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "commission_audit_log_commission_id_fkey"
            columns: ["commission_id"]
            isOneToOne: false
            referencedRelation: "commissions"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "commission_audit_log_changed_by_fkey"
            columns: ["changed_by"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          }
        ]
      }
      marketing_campaigns: {
        Row: {
          id: string
          name: string
          platform: 'Facebook' | 'Google' | 'TikTok' | 'Other'
          budget: number
          leads_generated: number
          appointments_set: number
          start_date: string
          end_date: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          name: string
          platform?: 'Facebook' | 'Google' | 'TikTok' | 'Other'
          budget?: number
          leads_generated?: number
          appointments_set?: number
          start_date?: string
          end_date?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          name?: string
          platform?: 'Facebook' | 'Google' | 'TikTok' | 'Other'
          budget?: number
          leads_generated?: number
          appointments_set?: number
          start_date?: string
          end_date?: string | null
          created_at?: string
          updated_at?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

export type AppUser = Database['public']['Tables']['users']['Row'];
export type Property = Database['public']['Tables']['properties']['Row'];
export type PropertyFeature = Database['public']['Tables']['property_features']['Row'];
export type Deal = Database['public']['Tables']['deals']['Row'];
export type Commission = Database['public']['Tables']['commissions']['Row'];
export type Expense = Database['public']['Tables']['expenses']['Row'];
export type Payment = Database['public']['Tables']['payments']['Row'];
export type PropertyImage = Database['public']['Tables']['property_images']['Row'];
export type AuditLog = Database['public']['Tables']['audit_log']['Row'];
export type CommissionAuditLog = Database['public']['Tables']['commission_audit_log']['Row'];
export type MarketingCampaign = Database['public']['Tables']['marketing_campaigns']['Row'];
