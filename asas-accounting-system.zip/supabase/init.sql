-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Enums
DO $$ BEGIN
    CREATE TYPE transaction_type AS ENUM ('NEW_DEAL', 'COMMISSION_TRANCHE', 'RESERVATION', 'REFUND', 'PARTNER_DRAW', 'EXPENSE');
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
    CREATE TYPE deal_status AS ENUM ('Reserved', 'Pending Balance', 'Fully Paid', 'Cancelled');
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
    CREATE TYPE expense_category AS ENUM ('Facebook Ads', 'Google Ads', 'Ouedkniss', 'Office', 'Salary', 'Misc');
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

-- Profiles Table (for RLS and roles)
CREATE TABLE IF NOT EXISTS public.profiles (
    id UUID REFERENCES auth.users(id) ON DELETE CASCADE PRIMARY KEY,
    full_name TEXT NOT NULL,
    role TEXT NOT NULL CHECK (role IN ('admin', 'agent')),
    is_locked BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- SECURITY FIX: Prevent Privilege Escalation on Signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER 
LANGUAGE plpgsql 
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  user_count INT;
BEGIN
  SELECT count(*) INTO user_count FROM public.profiles;
  
  INSERT INTO public.profiles (id, full_name, role)
  VALUES (
    new.id, 
    COALESCE(new.raw_user_meta_data->>'full_name', 'Unknown User'), 
    CASE WHEN user_count = 0 THEN 'admin' ELSE 'agent' END
  );
  RETURN new;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE PROCEDURE public.handle_new_user();

-- Partners Table
CREATE TABLE IF NOT EXISTS public.partners (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    name TEXT NOT NULL UNIQUE CHECK (name IN ('Hammou.HS', 'Redouane.AG')),
    equity_share NUMERIC NOT NULL CHECK (equity_share >= 0 AND equity_share <= 1),
    total_withdrawn NUMERIC DEFAULT 0 NOT NULL
);

INSERT INTO public.partners (name, equity_share) VALUES 
('Hammou.HS', 0.65),
('Redouane.AG', 0.35)
ON CONFLICT (name) DO NOTHING;

-- Developers Table
CREATE TABLE IF NOT EXISTS public.developers (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    name TEXT NOT NULL,
    contact_person TEXT,
    phone TEXT,
    email TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- Projects Table
CREATE TABLE IF NOT EXISTS public.projects (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    developer_id UUID REFERENCES public.developers(id) ON DELETE CASCADE NOT NULL,
    name TEXT NOT NULL,
    location TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- Clients Table
CREATE TABLE IF NOT EXISTS public.clients (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    full_name TEXT NOT NULL,
    phone TEXT NOT NULL,
    email TEXT,
    id_card_number TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- Deals Table
CREATE TABLE IF NOT EXISTS public.deals (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    project_id UUID REFERENCES public.projects(id) NOT NULL,
    client_id UUID REFERENCES public.clients(id) NOT NULL,
    agent_id UUID REFERENCES auth.users(id) NOT NULL,
    property_ref TEXT UNIQUE NOT NULL,
    property_price NUMERIC NOT NULL CHECK (property_price >= 0),
    total_expected_commission NUMERIC NOT NULL CHECK (total_expected_commission >= 0),
    total_received_commission NUMERIC DEFAULT 0 NOT NULL,
    total_agent_commission_due NUMERIC NOT NULL CHECK (total_agent_commission_due >= 0),
    total_agent_commission_paid NUMERIC DEFAULT 0 NOT NULL,
    deal_status deal_status DEFAULT 'Pending Balance' NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- Transactions Table (The Ledger)
CREATE TABLE IF NOT EXISTS public.transactions (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    deal_id UUID REFERENCES public.deals(id) ON DELETE CASCADE,
    partner_id UUID REFERENCES public.partners(id) ON DELETE CASCADE,
    type transaction_type NOT NULL,
    expense_cat expense_category,
    amount NUMERIC NOT NULL, 
    agent_commission_payout NUMERIC DEFAULT 0 NOT NULL CHECK (agent_commission_payout >= 0),
    description TEXT,
    performed_by UUID REFERENCES public.profiles(id),
    target_agent_id UUID REFERENCES public.profiles(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
    
    CONSTRAINT check_partner_draw CHECK (
        (type = 'PARTNER_DRAW' AND partner_id IS NOT NULL) OR 
        (type != 'PARTNER_DRAW' AND partner_id IS NULL)
    ),
    CONSTRAINT check_deal_transaction CHECK (
        (type IN ('NEW_DEAL', 'COMMISSION_TRANCHE', 'RESERVATION', 'REFUND') AND deal_id IS NOT NULL) OR 
        (type NOT IN ('NEW_DEAL', 'COMMISSION_TRANCHE', 'RESERVATION', 'REFUND'))
    ),
    CONSTRAINT check_expense_category CHECK (
        (type = 'EXPENSE' AND expense_cat IS NOT NULL) OR
        (type != 'EXPENSE' AND expense_cat IS NULL)
    ),
    CONSTRAINT check_amount_sign CHECK (
        (type IN ('NEW_DEAL', 'COMMISSION_TRANCHE', 'RESERVATION') AND amount >= 0) OR
        (type IN ('REFUND', 'PARTNER_DRAW', 'EXPENSE') AND amount <= 0)
    )
);

-- Trigger to set performed_by automatically
CREATE OR REPLACE FUNCTION set_performed_by()
RETURNS TRIGGER 
LANGUAGE plpgsql 
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
    IF NEW.performed_by IS NULL THEN
        NEW.performed_by = auth.uid();
    END IF;
    RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_set_performed_by ON public.transactions;
CREATE TRIGGER trg_set_performed_by
BEFORE INSERT ON public.transactions
FOR EACH ROW EXECUTE PROCEDURE set_performed_by();

-- PERFORMANCE: Add missing indexes for Foreign Keys
CREATE INDEX IF NOT EXISTS idx_projects_developer_id ON public.projects(developer_id);
CREATE INDEX IF NOT EXISTS idx_deals_project_id ON public.deals(project_id);
CREATE INDEX IF NOT EXISTS idx_deals_client_id ON public.deals(client_id);
CREATE INDEX IF NOT EXISTS idx_deals_agent_id ON public.deals(agent_id);
CREATE INDEX IF NOT EXISTS idx_transactions_deal_id ON public.transactions(deal_id);
CREATE INDEX IF NOT EXISTS idx_transactions_partner_id ON public.transactions(partner_id);
CREATE INDEX IF NOT EXISTS idx_transactions_type ON public.transactions(type);

-- Trigger Function to update Deals and Partners
CREATE OR REPLACE FUNCTION update_financials_trigger()
RETURNS TRIGGER 
LANGUAGE plpgsql 
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    v_deal_status deal_status;
BEGIN
    -- 1. PREVENT TRANSACTIONS ON CANCELLED DEALS
    IF (NEW.deal_id IS NOT NULL) THEN
        SELECT deal_status INTO v_deal_status FROM public.deals WHERE id = NEW.deal_id;
        IF v_deal_status = 'Cancelled' THEN
            RAISE EXCEPTION 'Cannot record transactions on a cancelled deal.';
        END IF;
    END IF;

    IF (NEW.deal_id IS NOT NULL OR OLD.deal_id IS NOT NULL) THEN
        DECLARE
            target_deal_id UUID := COALESCE(NEW.deal_id, OLD.deal_id);
            received NUMERIC;
            paid NUMERIC;
            expected NUMERIC;
            agent_due NUMERIC;
        BEGIN
            SELECT COALESCE(SUM(amount), 0) INTO received
            FROM public.transactions 
            WHERE deal_id = target_deal_id AND type IN ('NEW_DEAL', 'COMMISSION_TRANCHE', 'RESERVATION', 'REFUND');
            
            SELECT COALESCE(SUM(agent_commission_payout), 0) INTO paid
            FROM public.transactions 
            WHERE deal_id = target_deal_id;

            SELECT total_expected_commission, total_agent_commission_due 
            INTO expected, agent_due
            FROM public.deals WHERE id = target_deal_id;

            -- 2. PREVENT OVERPAYMENT OF AGENT
            IF paid > agent_due THEN
                RAISE EXCEPTION 'Agent payout (%) exceeds total commission due (%)', paid, agent_due;
            END IF;

            -- 3. PREVENT OVER-COLLECTION OF COMMISSION (Optional but safer)
            -- IF received > expected THEN
            --     RAISE EXCEPTION 'Total received commission (%) exceeds expected commission (%)', received, expected;
            -- END IF;

            UPDATE public.deals 
            SET 
                total_received_commission = received,
                total_agent_commission_paid = paid,
                deal_status = CASE 
                    WHEN received >= expected THEN 'Fully Paid'::deal_status
                    ELSE 'Pending Balance'::deal_status
                END
            WHERE id = target_deal_id;
        END;
    END IF;

    IF (NEW.type = 'PARTNER_DRAW' OR (TG_OP = 'DELETE' AND OLD.type = 'PARTNER_DRAW') OR (TG_OP = 'UPDATE' AND OLD.type = 'PARTNER_DRAW')) THEN
        DECLARE
            target_partner_id UUID := COALESCE(NEW.partner_id, OLD.partner_id);
            withdrawn NUMERIC;
        BEGIN
            SELECT COALESCE(SUM(ABS(amount)), 0) INTO withdrawn
            FROM public.transactions
            WHERE partner_id = target_partner_id AND type = 'PARTNER_DRAW';

            UPDATE public.partners
            SET total_withdrawn = withdrawn
            WHERE id = target_partner_id;
        END;
    END IF;

    RETURN NULL;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS on_transaction_change ON public.transactions;
CREATE TRIGGER on_transaction_change
AFTER INSERT OR UPDATE OR DELETE ON public.transactions
FOR EACH ROW EXECUTE PROCEDURE update_financials_trigger();

-- ACID COMPLIANCE: RPC for creating a deal and its first transaction atomically
CREATE OR REPLACE FUNCTION create_deal_with_transaction(
    p_project_id UUID,
    p_client_id UUID,
    p_agent_id UUID,
    p_property_ref TEXT,
    p_property_price NUMERIC,
    p_expected_commission NUMERIC,
    p_agent_commission_due NUMERIC,
    p_transaction_amount NUMERIC,
    p_agent_payout NUMERIC,
    p_description TEXT
) RETURNS UUID 
LANGUAGE plpgsql 
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    v_deal_id UUID;
    v_is_admin BOOLEAN;
BEGIN
    -- SECURITY CHECK: Only admins can create deals for other agents
    SELECT role = 'admin' INTO v_is_admin FROM public.profiles WHERE id = auth.uid();
    
    IF NOT v_is_admin AND p_agent_id != auth.uid() THEN
        RAISE EXCEPTION 'Access Denied: Agents can only create deals for themselves.';
    END IF;

    INSERT INTO public.deals (
        project_id, client_id, agent_id, property_ref, 
        property_price, total_expected_commission, total_agent_commission_due
    ) VALUES (
        p_project_id, p_client_id, p_agent_id, p_property_ref,
        p_property_price, p_expected_commission, p_agent_commission_due
    ) RETURNING id INTO v_deal_id;

    INSERT INTO public.transactions (
        deal_id, type, amount, agent_commission_payout, description
    ) VALUES (
        v_deal_id, 'NEW_DEAL', p_transaction_amount, p_agent_payout, p_description
    );

    RETURN v_deal_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- SECURITY FIX: Replace insecure view with a secure RPC for global equity reporting
DROP VIEW IF EXISTS public.view_partners_equity;

CREATE OR REPLACE FUNCTION public.get_partners_equity()
RETURNS TABLE (
    total_revenue NUMERIC,
    total_expenses NUMERIC,
    total_agent_payouts NUMERIC,
    net_profit NUMERIC,
    hammou_balance NUMERIC,
    redouane_balance NUMERIC
) 
LANGUAGE plpgsql 
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM public.profiles 
        WHERE id = auth.uid() AND role = 'admin'
    ) THEN
        RAISE EXCEPTION 'Access Denied: Only administrators can view partner equity.';
    END IF;

    RETURN QUERY
    WITH totals AS (
        SELECT 
            COALESCE(SUM(amount) FILTER (WHERE type IN ('NEW_DEAL', 'COMMISSION_TRANCHE', 'RESERVATION', 'REFUND')), 0) AS total_revenue,
            COALESCE(SUM(ABS(amount)) FILTER (WHERE type = 'EXPENSE'), 0) AS total_expenses,
            COALESCE(SUM(agent_commission_payout), 0) AS total_agent_payouts
        FROM public.transactions
    ),
    net_calc AS (
        SELECT 
            t.total_revenue,
            t.total_expenses,
            t.total_agent_payouts,
            (t.total_revenue - t.total_expenses - t.total_agent_payouts) AS net_profit
        FROM totals t
    )
    SELECT 
        n.total_revenue,
        n.total_expenses,
        n.total_agent_payouts,
        n.net_profit,
        (n.net_profit * 0.65) - (SELECT total_withdrawn FROM public.partners WHERE name = 'Hammou.HS') AS hammou_balance,
        (n.net_profit * 0.35) - (SELECT total_withdrawn FROM public.partners WHERE name = 'Redouane.AG') AS redouane_balance
    FROM net_calc n;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

REVOKE EXECUTE ON FUNCTION public.get_partners_equity() FROM public, anon;
GRANT EXECUTE ON FUNCTION public.get_partners_equity() TO authenticated;

-- Row Level Security (RLS)
ALTER TABLE public.developers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.projects ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.clients ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.deals ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.partners ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- RLS Policies
DROP POLICY IF EXISTS "Profiles viewable by admin or self" ON public.profiles;
CREATE POLICY "Profiles viewable by admin or self" ON public.profiles FOR SELECT 
USING (id = auth.uid() OR EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin'));

-- Developers, Projects, Clients (Viewable by all authenticated users, editable by admins)
CREATE POLICY "Everyone can view developers" ON public.developers FOR SELECT USING (true);
CREATE POLICY "Admins can insert developers" ON public.developers FOR INSERT WITH CHECK (EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin'));
CREATE POLICY "Admins can update developers" ON public.developers FOR UPDATE USING (EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin'));

CREATE POLICY "Everyone can view projects" ON public.projects FOR SELECT USING (true);
CREATE POLICY "Admins can insert projects" ON public.projects FOR INSERT WITH CHECK (EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin'));
CREATE POLICY "Admins can update projects" ON public.projects FOR UPDATE USING (EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin'));

CREATE POLICY "Everyone can view clients" ON public.clients FOR SELECT USING (true);
CREATE POLICY "Admins can insert clients" ON public.clients FOR INSERT WITH CHECK (EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin'));
CREATE POLICY "Admins can update clients" ON public.clients FOR UPDATE USING (EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin'));

-- Deals Policies
DROP POLICY IF EXISTS "Admins can view all deals" ON public.deals;
CREATE POLICY "Admins can view all deals" ON public.deals FOR SELECT 
USING (EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin'));

DROP POLICY IF EXISTS "Agents can view own deals" ON public.deals;
CREATE POLICY "Agents can view own deals" ON public.deals FOR SELECT 
USING (agent_id = auth.uid());

DROP POLICY IF EXISTS "Admins can insert deals" ON public.deals;
CREATE POLICY "Admins can insert deals" ON public.deals FOR INSERT 
WITH CHECK (EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin'));

DROP POLICY IF EXISTS "Agents can insert own deals" ON public.deals;
CREATE POLICY "Agents can insert own deals" ON public.deals FOR INSERT 
WITH CHECK (agent_id = auth.uid());

DROP POLICY IF EXISTS "Admins can update deals" ON public.deals;
CREATE POLICY "Admins can update deals" ON public.deals FOR UPDATE 
USING (EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin'));

DROP POLICY IF EXISTS "Agents can update own deals" ON public.deals;
CREATE POLICY "Agents can update own deals" ON public.deals FOR UPDATE 
USING (agent_id = auth.uid());

-- Transactions Policies
DROP POLICY IF EXISTS "Admins can view all transactions" ON public.transactions;
CREATE POLICY "Admins can view all transactions" ON public.transactions FOR SELECT 
USING (EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin'));

DROP POLICY IF EXISTS "Agents can view transactions for own deals" ON public.transactions;
CREATE POLICY "Agents can view transactions for own deals" ON public.transactions FOR SELECT 
USING (
    deal_id IN (SELECT id FROM public.deals WHERE agent_id = auth.uid()) OR
    EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin')
);

DROP POLICY IF EXISTS "Admins can insert transactions" ON public.transactions;
CREATE POLICY "Admins can insert transactions" ON public.transactions FOR INSERT 
WITH CHECK (EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin'));

CREATE POLICY "Admins can update transactions" ON public.transactions FOR UPDATE
USING (EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin'));

CREATE POLICY "Admins can delete transactions" ON public.transactions FOR DELETE
USING (EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin'));

DROP POLICY IF EXISTS "Agents can insert positive transactions for own deals" ON public.transactions;
CREATE POLICY "Agents can insert transactions" ON public.transactions FOR INSERT 
WITH CHECK (
    (deal_id IN (SELECT id FROM public.deals WHERE agent_id = auth.uid()) AND type IN ('NEW_DEAL', 'COMMISSION_TRANCHE', 'RESERVATION')) OR
    (type = 'EXPENSE')
);

-- ONE-TIME FIX: Ensure the current user is an admin if they were the first to sign up
-- (This is safe as the user confirmed they are the only one working on the app)
UPDATE public.profiles SET role = 'admin' WHERE role = 'agent';

-- Partners Policies
DROP POLICY IF EXISTS "Everyone can view partners" ON public.partners;
CREATE POLICY "Everyone can view partners" ON public.partners FOR SELECT USING (true);
