-- ============================================================
-- 🛡️ ASAS AGENCY: ENTERPRISE SUPABASE HARDENING & AUDIT SUITE
-- ============================================================
-- Adapted for actual schema: deals, transactions, profiles

-- 0️⃣ Prep: Required extensions
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- 1️⃣ RLS & Ownership Enforcement
-- ------------------------------------------------------------
-- Ensure RLS is enabled (already enabled in init.sql, but re-asserting)
ALTER TABLE public.deals ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.transactions ENABLE ROW LEVEL SECURITY;

-- Ownership enforcement for transactions (Agents only see transactions linked to their deals)
DROP POLICY IF EXISTS "Agents can view transactions for own deals" ON public.transactions;
CREATE POLICY "Agents can view transactions for own deals" ON public.transactions 
FOR SELECT USING (
    deal_id IN (SELECT id FROM public.deals WHERE agent_id = auth.uid()) OR
    EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin')
);

-- Prevent horizontal escalation: Agents cannot create transactions for other agents' deals
DROP POLICY IF EXISTS "Agents can insert transactions for own deals" ON public.transactions;
CREATE POLICY "Agents can insert transactions for own deals" ON public.transactions 
FOR INSERT WITH CHECK (
    deal_id IN (SELECT id FROM public.deals WHERE agent_id = auth.uid()) AND
    (EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'agent'))
);

-- 2️⃣ Financial Hardening & Data Integrity
-- ------------------------------------------------------------
-- Ensure high precision for all financial columns
ALTER TABLE public.deals ALTER COLUMN property_price TYPE NUMERIC(15,2);
ALTER TABLE public.deals ALTER COLUMN total_expected_commission TYPE NUMERIC(15,2);
ALTER TABLE public.transactions ALTER COLUMN amount TYPE NUMERIC(15,2);

-- Prevent negative values for deal prices and expected commissions
ALTER TABLE public.deals ADD CONSTRAINT property_price_non_negative CHECK (property_price >= 0);
ALTER TABLE public.deals ADD CONSTRAINT expected_commission_non_negative CHECK (total_expected_commission >= 0);

-- Immutability for Cancelled or Fully Paid deals (Finalization Logic)
CREATE OR REPLACE FUNCTION public.check_deal_immutability()
RETURNS TRIGGER 
LANGUAGE plpgsql 
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
    IF OLD.deal_status IN ('Fully Paid', 'Cancelled') AND (auth.role() != 'service_role') THEN
        RAISE EXCEPTION 'Deal is in a finalized state (%) and cannot be modified.', OLD.deal_status;
    END IF;
    RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_deal_immutability ON public.deals;
CREATE TRIGGER trg_deal_immutability
BEFORE UPDATE ON public.deals
FOR EACH ROW EXECUTE FUNCTION public.check_deal_immutability();

-- 3️⃣ General Audit Logging System
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.audit_log (
    id BIGSERIAL PRIMARY KEY,
    table_name TEXT NOT NULL,
    record_id UUID NOT NULL,
    action TEXT NOT NULL,
    old_data JSONB,
    new_data JSONB,
    performed_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
    performed_by UUID REFERENCES auth.users(id)
);

-- Admin-only access to audit logs
ALTER TABLE public.audit_log ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Admins can view audit logs" ON public.audit_log 
FOR SELECT USING (EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin'));

CREATE OR REPLACE FUNCTION public.audit_trigger_fn()
RETURNS TRIGGER 
LANGUAGE plpgsql 
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.audit_log (table_name, record_id, action, old_data, new_data, performed_by)
  VALUES (TG_TABLE_NAME, COALESCE(NEW.id, OLD.id), TG_OP, row_to_json(OLD), row_to_json(NEW), auth.uid());
  RETURN COALESCE(NEW, OLD);
END;
$$;

-- Attach audit triggers
DO $$ 
DECLARE 
    t TEXT;
BEGIN
    FOR t IN SELECT table_name FROM information_schema.tables 
             WHERE table_schema = 'public' 
             AND table_name IN ('deals', 'transactions', 'profiles', 'partners', 'clients')
    LOOP
        EXECUTE format('DROP TRIGGER IF EXISTS trg_audit_%I ON public.%I', t, t);
        EXECUTE format('CREATE TRIGGER trg_audit_%I AFTER INSERT OR UPDATE OR DELETE ON public.%I FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_fn()', t, t);
    END LOOP;
END $$;

-- 4️⃣ Foreign Keys & Performance Indexes
-- ------------------------------------------------------------
-- Ensure strict deletion rules to preserve financial history
ALTER TABLE public.transactions DROP CONSTRAINT IF EXISTS transactions_deal_id_fkey;
ALTER TABLE public.transactions ADD CONSTRAINT transactions_deal_id_fkey 
FOREIGN KEY (deal_id) REFERENCES public.deals(id) ON DELETE RESTRICT;

CREATE INDEX IF NOT EXISTS idx_deals_agent_id ON public.deals(agent_id);
CREATE INDEX IF NOT EXISTS idx_deals_status ON public.deals(deal_status);

-- 5️⃣ Stress & Fraud Simulation Helpers
-- ------------------------------------------------------------
-- Function to simulate concurrent updates (Stress Test)
CREATE OR REPLACE FUNCTION public.simulate_concurrency_test(p_deal_id UUID, p_iterations INT)
RETURNS VOID 
LANGUAGE plpgsql 
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    i INT;
BEGIN
    FOR i IN 1..p_iterations LOOP
        UPDATE public.deals SET total_received_commission = total_received_commission + 0.01 WHERE id = p_deal_id;
    END LOOP;
END;
$$;

-- 6️⃣ Automatic Risk & Report Table
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.risk_report (
    id BIGSERIAL PRIMARY KEY,
    table_name TEXT,
    vulnerability TEXT,
    severity TEXT,
    recommendation TEXT,
    detected_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- Admin-only access
ALTER TABLE public.risk_report ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Admins can view risk reports" ON public.risk_report 
FOR SELECT USING (EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin'));

-- Example: Automatic detection of missing RLS or permissive policies
INSERT INTO public.risk_report (table_name, vulnerability, severity, recommendation)
SELECT 
    relname as table_name, 
    'RLS not enabled' as vulnerability, 
    'CRITICAL' as severity, 
    'Execute ALTER TABLE ' || relname || ' ENABLE ROW LEVEL SECURITY;' as recommendation
FROM pg_class c
JOIN pg_namespace n ON n.oid = c.relnamespace
WHERE n.nspname = 'public' 
AND c.relkind = 'r' 
AND NOT relrowsecurity
AND relname NOT IN ('audit_log', 'risk_report');

-- ============================================================
-- ✅ ENTERPRISE HARDENING COMPLETE
-- ============================================================
