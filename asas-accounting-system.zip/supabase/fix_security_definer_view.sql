-- ============================================================
-- 🛡️ SECURITY FIX: RESOLVE SECURITY DEFINER VIEW ISSUE
-- ============================================================
-- Issue: View public.view_partners_equity is defined with SECURITY DEFINER.
-- Risk: Bypasses RLS of the querying user using the creator's permissions.
-- Resolution: Drop the insecure view and ensure the secure RPC replacement is hardened.

-- 1️⃣ Drop the insecure view if it exists
DROP VIEW IF EXISTS public.view_partners_equity;

-- 2️⃣ Harden the replacement function (get_partners_equity)
-- We use SECURITY DEFINER because it needs to aggregate data across all transactions
-- (which RLS would otherwise block for non-admins).
-- To make it secure, we:
--   a) Check the user's role internally.
--   b) Set a fixed search_path to prevent search path hijacking.
--   c) Revoke public execute permissions.

CREATE OR REPLACE FUNCTION public.get_partners_equity()
RETURNS TABLE (
    total_revenue NUMERIC,
    total_expenses NUMERIC,
    total_agent_payouts NUMERIC,
    net_profit NUMERIC,
    hammou_balance NUMERIC,
    redouane_balance NUMERIC
) 
LANGUAGE plpgsql 
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
    -- Internal Role Check: Only admins can bypass RLS for this aggregation
    IF NOT EXISTS (
        SELECT 1 FROM public.profiles 
        WHERE id = auth.uid() AND role = 'admin'
    ) THEN
        RAISE EXCEPTION 'Access Denied: Only administrators can view partner equity.';
    END IF;

    RETURN QUERY
    WITH totals AS (
        SELECT 
            COALESCE(SUM(amount) FILTER (WHERE type IN ('NEW_DEAL', 'COMMISSION_TRANCHE', 'RESERVATION', 'REFUND')), 0) AS total_revenue,
            COALESCE(SUM(ABS(amount)) FILTER (WHERE type = 'EXPENSE'), 0) AS total_expenses,
            COALESCE(SUM(agent_commission_payout), 0) AS total_agent_payouts
        FROM public.transactions
    ),
    net_calc AS (
        SELECT 
            t.total_revenue,
            t.total_expenses,
            t.total_agent_payouts,
            (t.total_revenue - t.total_expenses - t.total_agent_payouts) AS net_profit
        FROM totals t
    )
    SELECT 
        n.total_revenue,
        n.total_expenses,
        n.total_agent_payouts,
        n.net_profit,
        (n.net_profit * 0.65) - (SELECT total_withdrawn FROM public.partners WHERE name = 'Hammou.HS') AS hammou_balance,
        (n.net_profit * 0.35) - (SELECT total_withdrawn FROM public.partners WHERE name = 'Redouane.AG') AS redouane_balance
    FROM net_calc n;
END;
$$;

-- 3️⃣ Re-assert strict permissions
REVOKE EXECUTE ON FUNCTION public.get_partners_equity() FROM public, anon;
GRANT EXECUTE ON FUNCTION public.get_partners_equity() TO authenticated;

-- ============================================================
-- ✅ SECURITY ISSUE RESOLVED
-- ============================================================
