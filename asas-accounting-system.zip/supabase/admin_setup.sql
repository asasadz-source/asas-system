-- ============================================================
-- 👑 ASAS AGENCY: SUPER ADMIN ROLE & PRIVILEGED ACCESS
-- ============================================================
-- This script sets up a dedicated Postgres role for direct administrative access
-- and ensures RLS policies allow full access for privileged users.

-- 1️⃣ Create Super Admin Postgres Role (for direct DB connection)
-- ------------------------------------------------------------
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'hamou_admin') THEN
    -- Note: In a real production environment, use a very strong password.
    -- This role is intended for server-side or direct DB management.
    CREATE ROLE hamou_admin NOINHERIT LOGIN PASSWORD 'ASAS_Agency_Secure_Admin_2026';
  END IF;
END $$;

-- 2️⃣ Grant Full Permissions on Public Schema
-- ------------------------------------------------------------
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO hamou_admin;
GRANT USAGE, SELECT, UPDATE ON ALL SEQUENCES IN SCHEMA public TO hamou_admin;

-- 3️⃣ Hardened RLS Policies for Admin Access
-- ------------------------------------------------------------
-- We ensure that any user with the 'admin' role in the profiles table
-- has absolute authority over the core business data.

-- Tables to harden: deals, transactions, profiles, clients, projects, developers
DO $$
DECLARE
    t TEXT;
BEGIN
    FOR t IN SELECT table_name FROM information_schema.tables 
             WHERE table_schema = 'public' 
             AND table_name IN ('deals', 'transactions', 'profiles', 'clients', 'projects', 'developers', 'expenses', 'commissions')
    LOOP
        -- Enable RLS (just in case)
        EXECUTE format('ALTER TABLE public.%I ENABLE ROW LEVEL SECURITY', t);

        -- Create Full Access Policy for Admins
        EXECUTE format('DROP POLICY IF EXISTS "Admin full access on %I" ON public.%I', t, t);
        EXECUTE format('CREATE POLICY "Admin full access on %I" ON public.%I FOR ALL USING (EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = ''admin''))', t, t);
    END LOOP;
END $$;

-- 4️⃣ Admin Bypass for Service Role
-- ------------------------------------------------------------
-- Ensure the service_role (used by Supabase internal processes) can always bypass RLS.
-- This is default behavior in Supabase, but we re-assert it for clarity.
ALTER TABLE public.deals FORCE ROW LEVEL SECURITY;
ALTER TABLE public.transactions FORCE ROW LEVEL SECURITY;

-- 5️⃣ Audit Logging for Admin Actions
-- ------------------------------------------------------------
-- Admin actions are automatically captured by the audit triggers 
-- implemented in the enterprise_hardening.sql suite.
-- This ensures accountability even for the highest level of access.

-- ============================================================
-- ✅ ADMIN SETUP COMPLETE
-- ============================================================
