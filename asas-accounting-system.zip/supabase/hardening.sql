-- ==========================================
-- 🛡️ SUPABASE ENTERPRISE HARDENING SUITE
-- ==========================================

-- 1️⃣ IMMUTABLE AUDIT LOGGING SYSTEM
-- ------------------------------------------
CREATE TABLE IF NOT EXISTS public.audit_logs (
    id BIGSERIAL PRIMARY KEY,
    table_name TEXT NOT NULL,
    record_id UUID NOT NULL,
    action TEXT NOT NULL,
    old_data JSONB,
    new_data JSONB,
    performed_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
    performed_by UUID REFERENCES auth.users(id)
);

-- Enable RLS on Audit Logs (Admin only)
ALTER TABLE public.audit_logs ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Admins can view audit logs" ON public.audit_logs 
FOR SELECT USING (EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin'));

-- Generic Audit Trigger Function
CREATE OR REPLACE FUNCTION public.process_audit_log()
RETURNS TRIGGER AS $$
BEGIN
    IF (TG_OP = 'DELETE') THEN
        INSERT INTO public.audit_logs (table_name, record_id, action, old_data, performed_by)
        VALUES (TG_TABLE_NAME, OLD.id, TG_OP, row_to_json(OLD), auth.uid());
        RETURN OLD;
    ELSIF (TG_OP = 'UPDATE') THEN
        INSERT INTO public.audit_logs (table_name, record_id, action, old_data, new_data, performed_by)
        VALUES (TG_TABLE_NAME, NEW.id, TG_OP, row_to_json(OLD), row_to_json(NEW), auth.uid());
        RETURN NEW;
    ELSIF (TG_OP = 'INSERT') THEN
        INSERT INTO public.audit_logs (table_name, record_id, action, new_data, performed_by)
        VALUES (TG_TABLE_NAME, NEW.id, TG_OP, row_to_json(NEW), auth.uid());
        RETURN NEW;
    END IF;
    RETURN NULL;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Attach Audit Triggers to Sensitive Tables
DO $$ 
DECLARE 
    t TEXT;
BEGIN
    FOR t IN SELECT table_name FROM information_schema.tables 
             WHERE table_schema = 'public' 
             AND table_name IN ('deals', 'transactions', 'profiles', 'partners', 'clients')
    LOOP
        EXECUTE format('DROP TRIGGER IF EXISTS trg_audit_%I ON public.%I', t, t);
        EXECUTE format('CREATE TRIGGER trg_audit_%I AFTER INSERT OR UPDATE OR DELETE ON public.%I FOR EACH ROW EXECUTE FUNCTION public.process_audit_log()', t, t);
    END LOOP;
END $$;

-- 2️⃣ FINANCIAL DATA INTEGRITY & IMMUTABILITY
-- ------------------------------------------

-- Add "is_finalized" to Deals to lock them
ALTER TABLE public.deals ADD COLUMN IF NOT EXISTS is_finalized BOOLEAN DEFAULT FALSE;

-- Trigger to prevent editing finalized deals
CREATE OR REPLACE FUNCTION public.prevent_edit_finalized_deal()
RETURNS TRIGGER AS $$
BEGIN
    IF OLD.is_finalized AND (auth.role() != 'service_role') THEN
        RAISE EXCEPTION 'This deal is finalized and immutable. Contact an administrator for corrections.';
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE TRIGGER trg_prevent_edit_finalized_deal
BEFORE UPDATE ON public.deals
FOR EACH ROW EXECUTE FUNCTION public.prevent_edit_finalized_deal();

-- Ensure Numeric Precision (NUMERIC(15,2))
ALTER TABLE public.deals ALTER COLUMN property_price TYPE NUMERIC(15,2);
ALTER TABLE public.deals ALTER COLUMN total_expected_commission TYPE NUMERIC(15,2);
ALTER TABLE public.deals ALTER COLUMN total_received_commission TYPE NUMERIC(15,2);
ALTER TABLE public.deals ALTER COLUMN total_agent_commission_due TYPE NUMERIC(15,2);
ALTER TABLE public.deals ALTER COLUMN total_agent_commission_paid TYPE NUMERIC(15,2);
ALTER TABLE public.transactions ALTER COLUMN amount TYPE NUMERIC(15,2);
ALTER TABLE public.transactions ALTER COLUMN agent_commission_payout TYPE NUMERIC(15,2);

-- 3️⃣ ROLE & API SECURITY HARDENING
-- ------------------------------------------

-- Restrict 'anon' access (Zero Trust)
REVOKE ALL ON ALL TABLES IN SCHEMA public FROM anon;
GRANT SELECT ON public.profiles TO authenticated; -- Allow users to see their own profile (RLS handles filtering)

-- Hardened RLS for Profiles (Prevent self-role-modification)
DROP POLICY IF EXISTS "Profiles viewable by admin or self" ON public.profiles;
CREATE POLICY "Profiles viewable by admin or self" ON public.profiles FOR SELECT 
USING (id = auth.uid() OR EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin'));

CREATE POLICY "Users cannot update their own role" ON public.profiles FOR UPDATE
USING (id = auth.uid())
WITH CHECK (
    (SELECT role FROM public.profiles WHERE id = auth.uid()) = role -- Role must remain the same
    OR EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin') -- Unless admin
);

-- 4️⃣ STORAGE SECURITY
-- ------------------------------------------

-- Create 'contracts' bucket if it doesn't exist
INSERT INTO storage.buckets (id, name, public) 
VALUES ('contracts', 'contracts', false)
ON CONFLICT (id) DO NOTHING;

-- Storage RLS Policies
CREATE POLICY "Admins have full access to contracts"
ON storage.objects FOR ALL
TO authenticated
USING (bucket_id = 'contracts' AND EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin'));

CREATE POLICY "Agents can upload and view their own deal contracts"
ON storage.objects FOR ALL
TO authenticated
USING (
    bucket_id = 'contracts' AND 
    (storage.foldername(name))[1] IN (SELECT id::text FROM public.deals WHERE agent_id = auth.uid())
);

-- 5️⃣ DATA INTEGRITY & ORPHAN PREVENTION
-- ------------------------------------------

-- Prevent deletion of transactions when a deal is deleted (Financial History preservation)
ALTER TABLE public.transactions DROP CONSTRAINT IF EXISTS transactions_deal_id_fkey;
ALTER TABLE public.transactions ADD CONSTRAINT transactions_deal_id_fkey 
FOREIGN KEY (deal_id) REFERENCES public.deals(id) ON DELETE RESTRICT;

-- 6️⃣ FRAUD SIMULATION & STRESS TEST HELPERS
-- ------------------------------------------

-- Function to simulate high-concurrency transaction flood (for testing)
CREATE OR REPLACE FUNCTION public.simulate_transaction_flood(p_deal_id UUID, p_count INT)
RETURNS VOID AS $$
DECLARE
    i INT;
BEGIN
    FOR i IN 1..p_count LOOP
        INSERT INTO public.transactions (deal_id, type, amount, description)
        VALUES (p_deal_id, 'COMMISSION_TRANCHE', 1.00, 'Stress Test Load');
    END LOOP;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- ==========================================
-- ✅ HARDENING COMPLETE
-- ==========================================
