-- ============================================================
-- 🧪 ASAS AGENCY: SEED TEST DEAL & TRANSACTION
-- ============================================================
-- This script adapts the user's request to the actual database schema.

DO $$
DECLARE
    v_developer_id UUID;
    v_project_id UUID;
    v_client_id UUID;
    v_agent_id UUID;
    v_deal_id UUID;
BEGIN
    -- 1. Ensure Developer exists
    INSERT INTO public.developers (name)
    VALUES ('Promotion Cheraga')
    ON CONFLICT (name) DO NOTHING;
    SELECT id INTO v_developer_id FROM public.developers WHERE name = 'Promotion Cheraga';

    -- 2. Ensure Project exists
    INSERT INTO public.projects (developer_id, name, location)
    VALUES (v_developer_id, 'Cheraga Residence', 'Cheraga, Algiers')
    ON CONFLICT (name) DO NOTHING; -- Assuming name is unique per developer or globally
    SELECT id INTO v_project_id FROM public.projects WHERE developer_id = v_developer_id AND name = 'Cheraga Residence' LIMIT 1;

    -- 3. Ensure Client exists
    INSERT INTO public.clients (full_name, phone)
    VALUES ('Test Client', '0555000000')
    ON CONFLICT (full_name) DO NOTHING;
    SELECT id INTO v_client_id FROM public.clients WHERE full_name = 'Test Client' LIMIT 1;

    -- 4. Identify an Agent (Pick the first available agent profile)
    SELECT id INTO v_agent_id FROM public.profiles WHERE role = 'agent' LIMIT 1;
    
    -- Fallback: If no agent exists, use any profile
    IF v_agent_id IS NULL THEN
        SELECT id INTO v_agent_id FROM public.profiles LIMIT 1;
    END IF;

    -- 5. Insert the Deal (Cheraga Promotion)
    -- We use property_ref 'CH-TEST-001' to ensure uniqueness
    IF v_agent_id IS NOT NULL AND v_project_id IS NOT NULL AND v_client_id IS NOT NULL THEN
        INSERT INTO public.deals (
            project_id, 
            client_id, 
            agent_id, 
            property_ref, 
            property_price, 
            total_expected_commission, 
            total_agent_commission_due,
            deal_status
        )
        VALUES (
            v_project_id, 
            v_client_id, 
            v_agent_id, 
            'CH-TEST-001', 
            15000000, 
            450000, 
            45000, -- Assuming 10% agent commission for the test
            'Pending Balance'
        )
        ON CONFLICT (property_ref) DO NOTHING
        RETURNING id INTO v_deal_id;

        -- 6. Insert the First Transaction (Commission Tranche)
        IF v_deal_id IS NOT NULL THEN
            INSERT INTO public.transactions (deal_id, partner_id, type, amount, description)
            VALUES (
                v_deal_id, 
                (SELECT id FROM public.partners WHERE name = 'Hammou.HS' LIMIT 1), 
                'NEW_DEAL', 
                100000, 
                'First Tranche - Cheraga Promotion'
            );
        END IF;
    END IF;
END $$;

-- ============================================================
-- ✅ TEST DATA SEEDED
-- ============================================================
