-- ==============================
-- 1️⃣ Users Table
-- ==============================
CREATE TABLE IF NOT EXISTS users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    phone TEXT,
    role TEXT CHECK (role IN ('admin','agent','client')) NOT NULL,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- ==============================
-- 2️⃣ Properties Table
-- ==============================
CREATE TABLE IF NOT EXISTS properties (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    type TEXT CHECK (type IN ('apartment','villa','commercial')) NOT NULL,
    location TEXT NOT NULL,
    price NUMERIC(12,2) NOT NULL CHECK(price >= 0),
    status TEXT CHECK (status IN ('available','reserved','sold')) DEFAULT 'available',
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- ==============================
-- 3️⃣ Property Features Table
-- ==============================
CREATE TABLE IF NOT EXISTS property_features (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    property_id UUID REFERENCES properties(id) ON DELETE CASCADE,
    rooms INT CHECK(rooms >= 0),
    bathrooms INT CHECK(bathrooms >= 0),
    surface NUMERIC(8,2) CHECK(surface >= 0),
    balcony BOOLEAN DEFAULT FALSE,
    parking BOOLEAN DEFAULT FALSE,
    elevator BOOLEAN DEFAULT FALSE
);

-- ==============================
-- 4️⃣ Marketing Campaigns Table
-- ==============================
CREATE TABLE IF NOT EXISTS marketing_campaigns (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    platform TEXT CHECK (platform IN ('facebook', 'google', 'tiktok', 'instagram', 'other')) NOT NULL,
    budget NUMERIC(12,2) CHECK(budget >= 0),
    spent NUMERIC(12,2) CHECK(spent >= 0) DEFAULT 0,
    start_date DATE,
    end_date DATE,
    status TEXT CHECK (status IN ('active', 'paused', 'completed')) DEFAULT 'active',
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- ==============================
-- 5️⃣ Deals Table
-- ==============================
CREATE TABLE IF NOT EXISTS deals (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    property_id UUID REFERENCES properties(id),
    buyer_id UUID REFERENCES users(id),
    agent_id UUID REFERENCES users(id),
    marketing_campaign_id UUID REFERENCES marketing_campaigns(id),
    status TEXT CHECK (status IN ('pending','finalized','cancelled')) DEFAULT 'pending',
    total_amount NUMERIC(12,2) CHECK(total_amount >= 0),
    finalized_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- ==============================
-- 6️⃣ Commissions Table
-- ==============================
CREATE TABLE IF NOT EXISTS commissions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    deal_id UUID REFERENCES deals(id) ON DELETE CASCADE,
    agent_id UUID REFERENCES users(id),
    amount NUMERIC(12,2) CHECK(amount >= 0),
    status TEXT CHECK(status IN ('pending','paid')) DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- ==============================
-- 7️⃣ Expenses Table
-- ==============================
CREATE TABLE IF NOT EXISTS expenses (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    category TEXT CHECK(category IN ('marketing','maintenance','other')) NOT NULL,
    description TEXT,
    amount NUMERIC(12,2) CHECK(amount >= 0),
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMP DEFAULT NOW()
);

-- ==============================
-- 8️⃣ Payments Table
-- ==============================
CREATE TABLE IF NOT EXISTS payments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    deal_id UUID REFERENCES deals(id),
    type TEXT CHECK(type IN ('deposit','final','commission')) NOT NULL,
    amount NUMERIC(12,2) CHECK(amount >= 0),
    status TEXT CHECK(status IN ('pending','completed')) DEFAULT 'pending',
    paid_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- ==============================
-- 9️⃣ Property Images Table
-- ==============================
CREATE TABLE IF NOT EXISTS property_images (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    property_id UUID REFERENCES properties(id) ON DELETE CASCADE,
    url TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT NOW()
);

-- ==============================
-- 10️⃣ Audit Logs Table
-- ==============================
CREATE TABLE IF NOT EXISTS audit_log (
    id BIGSERIAL PRIMARY KEY,
    table_name TEXT NOT NULL,
    record_id UUID,
    action TEXT CHECK(action IN ('insert','update','delete')) NOT NULL,
    old_data JSONB,
    new_data JSONB,
    performed_by UUID REFERENCES users(id),
    performed_at TIMESTAMP DEFAULT NOW()
);

-- ==============================
-- 11️⃣ Commission Audit Logs Table
-- ==============================
CREATE TABLE IF NOT EXISTS commission_audit_log (
    id BIGSERIAL PRIMARY KEY,
    commission_id UUID REFERENCES commissions(id),
    old_amount NUMERIC(12,2),
    new_amount NUMERIC(12,2),
    changed_by UUID REFERENCES users(id),
    changed_at TIMESTAMP DEFAULT NOW()
);

-- ==============================
-- 12️⃣ Triggers Example for Audit Logs
-- ==============================
-- This example is for commissions, replicate for deals, expenses, etc.
CREATE OR REPLACE FUNCTION log_commission_changes()
RETURNS TRIGGER AS $$
BEGIN
    IF (TG_OP = 'INSERT') THEN
        INSERT INTO audit_log(table_name, record_id, action, new_data, performed_by)
        VALUES('commissions', NEW.id, TG_OP, row_to_json(NEW), current_setting('app.current_user', true)::uuid);
        RETURN NEW;
    ELSIF (TG_OP = 'UPDATE') THEN
        INSERT INTO audit_log(table_name, record_id, action, old_data, new_data, performed_by)
        VALUES('commissions', NEW.id, TG_OP, row_to_json(OLD), row_to_json(NEW), current_setting('app.current_user', true)::uuid);
        RETURN NEW;
    ELSIF (TG_OP = 'DELETE') THEN
        INSERT INTO audit_log(table_name, record_id, action, old_data, performed_by)
        VALUES('commissions', OLD.id, TG_OP, row_to_json(OLD), current_setting('app.current_user', true)::uuid);
        RETURN OLD;
    END IF;
    RETURN NULL;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_commission_audit
AFTER INSERT OR UPDATE OR DELETE ON commissions
FOR EACH ROW EXECUTE FUNCTION log_commission_changes();
