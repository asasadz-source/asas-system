-- ==============================
-- Seed Data for Asas Real Estate
-- ==============================

-- 1. Insert Users (Admin, Agents, Clients)
INSERT INTO users (id, name, email, phone, role) VALUES
('11111111-1111-1111-1111-111111111111', 'Admin User', 'admin@asas.com', '0555000000', 'admin'),
('22222222-2222-2222-2222-222222222222', 'Agent One', 'agent1@asas.com', '0555111111', 'agent'),
('33333333-3333-3333-3333-333333333333', 'Agent Two', 'agent2@asas.com', '0555222222', 'agent'),
('44444444-4444-4444-4444-444444444444', 'Client One', 'client1@example.com', '0555333333', 'client'),
('55555555-5555-5555-5555-555555555555', 'Client Two', 'client2@example.com', '0555444444', 'client')
ON CONFLICT (email) DO NOTHING;

-- 2. Insert Properties
INSERT INTO properties (id, type, location, price, status, created_by) VALUES
('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', 'apartment', 'Algiers Center', 15000000, 'available', '11111111-1111-1111-1111-111111111111'),
('bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb', 'villa', 'Hydra', 45000000, 'available', '11111111-1111-1111-1111-111111111111'),
('cccccccc-cccc-cccc-cccc-cccccccccccc', 'commercial', 'Bab Ezzouar', 25000000, 'available', '11111111-1111-1111-1111-111111111111')
ON CONFLICT DO NOTHING;

-- 3. Insert Property Features
INSERT INTO property_features (property_id, rooms, bathrooms, surface, balcony, parking, elevator) VALUES
('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', 3, 1, 85.5, TRUE, FALSE, TRUE),
('bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb', 6, 3, 250.0, TRUE, TRUE, FALSE),
('cccccccc-cccc-cccc-cccc-cccccccccccc', 0, 2, 120.0, FALSE, TRUE, TRUE)
ON CONFLICT DO NOTHING;

-- 4. Insert Marketing Campaigns
INSERT INTO marketing_campaigns (id, name, platform, budget, spent, start_date, end_date, status) VALUES
('dddddddd-dddd-dddd-dddd-dddddddddddd', 'Summer Promo', 'facebook', 50000, 25000, '2023-06-01', '2023-08-31', 'completed'),
('eeeeeeee-eeee-eeee-eeee-eeeeeeeeeeee', 'Luxury Villas', 'instagram', 100000, 45000, '2023-09-01', '2023-12-31', 'active')
ON CONFLICT DO NOTHING;

-- 5. Insert Deals
INSERT INTO deals (id, property_id, buyer_id, agent_id, marketing_campaign_id, status, total_amount) VALUES
('ffffffff-ffff-ffff-ffff-ffffffffffff', 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', '44444444-4444-4444-4444-444444444444', '22222222-2222-2222-2222-222222222222', 'dddddddd-dddd-dddd-dddd-dddddddddddd', 'pending', 15000000)
ON CONFLICT DO NOTHING;

-- 6. Insert Commissions
INSERT INTO commissions (deal_id, agent_id, amount, status) VALUES
('ffffffff-ffff-ffff-ffff-ffffffffffff', '22222222-2222-2222-2222-222222222222', 300000, 'pending')
ON CONFLICT DO NOTHING;

-- 7. Insert Payments
INSERT INTO payments (deal_id, type, amount, status, paid_at) VALUES
('ffffffff-ffff-ffff-ffff-ffffffffffff', 'deposit', 1500000, 'completed', NOW())
ON CONFLICT DO NOTHING;

-- 8. Insert Expenses
INSERT INTO expenses (category, description, amount, created_by) VALUES
('marketing', 'Facebook Ads for Summer Promo', 25000, '11111111-1111-1111-1111-111111111111'),
('maintenance', 'Office Cleaning', 5000, '11111111-1111-1111-1111-111111111111')
ON CONFLICT DO NOTHING;
